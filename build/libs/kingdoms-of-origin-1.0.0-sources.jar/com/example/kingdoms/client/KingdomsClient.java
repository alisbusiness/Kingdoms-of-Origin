package com.example.kingdoms.client;

import com.example.kingdoms.network.Net;
import io.netty.buffer.Unpooled;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.minecraft.class_2540;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public final class KingdomsClient implements ClientModInitializer {

    private static class_304 viewOriginKey;

    @Override
    public void onInitializeClient() {
        viewOriginKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.kingdoms_of_origin.view_origin",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                "category.kingdoms_of_origin"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (viewOriginKey.method_1436()) {
                if (client.field_1724 == null) continue;
                ClientPlayNetworking.send(Net.REQUEST_ORIGIN, new class_2540(Unpooled.buffer()));
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(Net.SHOW_ORIGIN, (client, handler, buf, sender) -> {
            String originId = buf.method_19772();
            client.execute(() -> client.method_1507(new OriginInfoScreen(originId)));
        });
    }
}
