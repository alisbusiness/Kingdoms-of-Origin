package com.example.kingdoms.client;

import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;
import net.minecraft.class_5481;

public final class OriginInfoScreen extends class_437 {

    private static final List<String> KING_POWERS = List.of(
            "Iron Fist (+3 attack damage)",
            "Crown's Resilience (+5 hearts, +4 armor, +2 toughness)",
            "Sovereign's March (+15% movement speed)",
            "Royal Radiance (you glow)",
            "Mark of the Crown (-0.2 knockback resistance)",
            "Undeniable Presence (immune to invisibility)",
            "Divine Flight (creative-style flight)",
            "Soft Hands (-30% mining speed)",
            "Prime Target (+50% projectile damage taken)",
            "Creature of Light (cursed in darkness)",
            "Royal Decree — Primary Active (rally nearby subjects)",
            "Wrath of the King — Secondary Active (call lightning)"
    );

    private final String originId;
    private final class_2561 title;
    private final class_2561 description;
    private final List<String> powers;

    public OriginInfoScreen(String originId) {
        super(class_2561.method_43470("Your Origin"));
        this.originId = originId == null ? "" : originId;
        switch (this.originId) {
            case "kingdoms_of_origin:king" -> {
                this.field_22785       = class_2561.method_43470("The King").method_27695(class_124.field_1065, class_124.field_1067);
                this.description = class_2561.method_43470(
                        "You bear the crown of the realm. Power flows through you, but the weight of rule is heavy."
                ).method_27692(class_124.field_1054);
                this.powers = KING_POWERS;
            }
            case "kingdoms_of_origin:human" -> {
                this.field_22785       = class_2561.method_43470("Subject of the Realm").method_27695(class_124.field_1068, class_124.field_1067);
                this.description = class_2561.method_43470(
                        "An ordinary citizen of the kingdom. You hold no special power, but the crown could yet find its way to you."
                ).method_27692(class_124.field_1080);
                this.powers = List.of();
            }
            default -> {
                this.field_22785       = class_2561.method_43470("No Origin").method_27695(class_124.field_1061, class_124.field_1067);
                this.description = class_2561.method_43470(
                        "Your origin could not be determined. (" + this.originId + ")"
                ).method_27692(class_124.field_1080);
                this.powers = List.of();
            }
        }
    }

    @Override
    protected void method_25426() {
        super.method_25426();
        method_37063(class_4185.method_46430(class_2561.method_43470("Close"), b -> method_25419())
                .method_46434(this.field_22789 / 2 - 50, this.field_22790 - 36, 100, 20)
                .method_46431());
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        method_25420(context);
        class_327 tr = this.field_22793;

        int centerX = this.field_22789 / 2;
        int y = 30;

        context.method_27534(tr, this.field_22785, centerX, y, 0xFFFFFFFF);
        y += 18;

        int wrapWidth = Math.min(this.field_22789 - 60, 320);
        for (var line : tr.method_1728(this.description, wrapWidth)) {
            context.method_35719(tr, line, centerX, y, 0xFFFFFFFF);
            y += 12;
        }

        if (!this.powers.isEmpty()) {
            y += 10;
            context.method_27534(tr,
                    class_2561.method_43470("Powers").method_27692(class_124.field_1073), centerX, y, 0xFFFFFFFF);
            y += 14;
            for (String p : this.powers) {
                context.method_27534(tr, class_2561.method_43470("• " + p), centerX, y, 0xFFDDDDDD);
                y += 11;
            }
        }

        super.method_25394(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean method_25421() { return false; }
}
