package com.example.kingdoms.network;

import com.example.kingdoms.KingdomsPlugin;
import net.minecraft.class_2960;

public final class Net {
    private Net() {}

    public static final class_2960 REQUEST_ORIGIN = new class_2960(KingdomsPlugin.MOD_ID, "request_origin");
    public static final class_2960 SHOW_ORIGIN    = new class_2960(KingdomsPlugin.MOD_ID, "show_origin");
}
