package com.example.kingdoms.network;

import com.example.kingdoms.origin.OriginAdapter;
import io.netty.buffer.Unpooled;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_2540;

public final class ServerNetworking {
    private ServerNetworking() {}

    public static void register(OriginAdapter adapter) {
        ServerPlayNetworking.registerGlobalReceiver(Net.REQUEST_ORIGIN, (server, player, handler, buf, responseSender) ->
            server.execute(() -> {
                String originId = "";
                if (adapter != null) {
                    String current = adapter.getCurrentOrigin(player);
                    if (current != null) originId = current;
                }
                class_2540 out = new class_2540(Unpooled.buffer());
                out.method_10814(originId);
                ServerPlayNetworking.send(player, Net.SHOW_ORIGIN, out);
            }));
    }
}
