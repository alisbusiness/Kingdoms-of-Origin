package com.example.kingdoms.perk;

import net.minecraft.class_1792;

public record PerkDefinition(
    String id,
    String name,
    PerkCategory category,
    PerkKind kind,
    class_1792 icon,
    String description,
    boolean wartime
) {
    public int cost() {
        return kind.cost();
    }
}
