package com.example.kingdoms.perk;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_1802;

public final class PerkRegistry {
    public static final int POLICY_POINTS = 20;

    private static final Map<String, PerkDefinition> PERKS = new LinkedHashMap<>();

    static {
        labor();
        military();
        economic();
        social();
        corruption();
    }

    private PerkRegistry() {}

    public static List<PerkDefinition> all() {
        return List.copyOf(PERKS.values());
    }

    public static List<PerkDefinition> byCategory(PerkCategory category) {
        return PERKS.values().stream()
            .filter(perk -> perk.category() == category)
            .sorted(Comparator.comparing(PerkDefinition::name))
            .toList();
    }

    public static Optional<PerkDefinition> find(String rawId) {
        String id = normalize(rawId);
        return Optional.ofNullable(PERKS.get(id));
    }

    public static List<String> parseIds(String raw) {
        if (raw == null || raw.isBlank()) return List.of();
        List<String> ids = new ArrayList<>();
        for (String token : raw.split("[,\\s]+")) {
            if (!token.isBlank()) ids.add(normalize(token));
        }
        return ids;
    }

    public static String serialize(List<String> ids) {
        return String.join(",", ids.stream().map(PerkRegistry::normalize).distinct().toList());
    }

    public static String normalize(String rawId) {
        String id = rawId == null ? "" : rawId.trim().toLowerCase(Locale.ROOT);
        int colon = id.indexOf(':');
        if (colon >= 0) id = id.substring(colon + 1);
        if (id.startsWith("perks/")) id = id.substring("perks/".length());
        return id;
    }

    public static BudgetResult validateBudget(List<String> ids) {
        int spent = 0;
        Map<PerkCategory, String> seen = new LinkedHashMap<>();
        List<String> errors = new ArrayList<>();
        for (String raw : ids) {
            PerkDefinition perk = PERKS.get(normalize(raw));
            if (perk == null) {
                errors.add("Unknown perk: " + raw);
                continue;
            }
            if (seen.containsKey(perk.category())) {
                errors.add("Only one " + perk.category().displayName() + " perk may be active.");
            } else {
                seen.put(perk.category(), perk.id());
            }
            spent += perk.cost();
        }
        int remaining = POLICY_POINTS - Math.max(0, spent);
        if (spent > POLICY_POINTS) errors.add("Policy budget exceeded by " + (spent - POLICY_POINTS) + " points.");
        return new BudgetResult(errors.isEmpty(), spent, remaining, List.copyOf(errors));
    }

    private static void add(String id, String name, PerkCategory category, PerkKind kind, net.minecraft.class_1792 icon, String description) {
        PERKS.put(id, new PerkDefinition(id, name, category, kind, icon, description, description.contains("Wartime")));
    }

    private static void labor() {
        add("iron_mandate", "Iron Mandate", PerkCategory.LABOR, PerkKind.MODERATE, class_1802.field_8403, "By royal order, every mined iron or copper ore has a one-in-three chance to drop an extra raw ore.");
        add("stone_covenant", "Stone Covenant", PerkCategory.LABOR, PerkKind.MINOR, class_1802.field_20391, "The crown blesses public works: breaking stone below Y=32 grants Haste I for 12 seconds.");
        add("breadline", "Breadline", PerkCategory.LABOR, PerkKind.MINOR, class_1802.field_8861, "The granaries open: harvesting fully grown wheat, carrots, potatoes, or beetroot restores 1 hunger once every 20 seconds.");
        add("charcoal_charter", "Charcoal Charter", PerkCategory.LABOR, PerkKind.MINOR, class_1802.field_8665, "The forests serve the realm: chopping logs has a one-in-four chance to drop charcoal.");
        add("deep_levy", "Deep Levy", PerkCategory.LABOR, PerkKind.STRONG, class_1802.field_8377, "The mines are mobilized: breaking deepslate ores grants Haste II for 10 seconds and 1 experience point.");
        add("green_commons", "Green Commons", PerkCategory.LABOR, PerkKind.MODERATE, class_1802.field_17535, "The commons are protected: breaking leaves has a one-in-five chance to return a matching sapling or apple.");
        add("canal_act", "Canal Act", PerkCategory.LABOR, PerkKind.MODERATE, class_1802.field_8705, "State canals speed labor: mining or harvesting while wet grants Dolphin's Grace for 8 seconds.");
        add("granary_audit", "Granary Audit", PerkCategory.LABOR, PerkKind.DEBUFF, class_1802.field_8635, "The crown audits every harvest: crop harvesting sometimes withholds the bonus yield and refunds 3 Policy Points.");
        add("timber_quota", "Timber Quota", PerkCategory.LABOR, PerkKind.STRONG, class_1802.field_8556, "Royal quotas bite: every tenth log chopped drops two extra sticks and grants Haste II for 15 seconds.");
        add("quarry_whistle", "Quarry Whistle", PerkCategory.LABOR, PerkKind.MODERATE, class_1802.field_16315, "When a miner breaks coal, redstone, or lapis ore, nearby subjects gain Haste I for 8 seconds.");
    }

    private static void military() {
        add("peoples_blade", "The People's Blade", PerkCategory.MILITARY, PerkKind.MODERATE, class_1802.field_8371, "Militia law is declared: after killing a hostile mob, gain Strength I for 10 seconds.");
        add("shield_wall_decree", "Shield Wall Decree", PerkCategory.MILITARY, PerkKind.MINOR, class_1802.field_8255, "The guard holds formation: blocking damage grants Resistance I for 6 seconds.");
        add("wolf_tax", "Wolf Tax", PerkCategory.MILITARY, PerkKind.MODERATE, class_1802.field_8606, "Kennels are funded: killing a skeleton has a one-in-four chance to grant Speed I for 12 seconds.");
        add("last_stand_clause", "Last Stand Clause", PerkCategory.MILITARY, PerkKind.STRONG, class_1802.field_8288, "No subject falls quietly: dropping below 5 hearts grants Resistance II for 8 seconds once per minute.");
        add("monster_bounty", "Monster Bounty", PerkCategory.MILITARY, PerkKind.MINOR, class_1802.field_8511, "The treasury pays for safety: killing hostile mobs grants 1 extra experience.");
        add("siege_rations", "Siege Rations", PerkCategory.MILITARY, PerkKind.MODERATE, class_1802.field_8176, "Wartime rations begin: everyone gains Strength I after eating but loses 1 hunger immediately.");
        add("blood_standard", "Blood Standard", PerkCategory.MILITARY, PerkKind.STRONG, class_1802.field_8586, "Wartime banners rise: everyone gains Strength I while below half health but has 2 fewer max hearts.");
        add("powder_inspection", "Powder Inspection", PerkCategory.MILITARY, PerkKind.MODERATE, class_1802.field_8054, "Explosives are regulated: creeper and TNT damage grants Fire Resistance and Resistance for 8 seconds.");
        add("draft_notice", "Draft Notice", PerkCategory.MILITARY, PerkKind.DEBUFF, class_1802.field_8523, "The draft burdens all subjects: combat kills no longer trigger bounty XP and refund 3 Policy Points.");
        add("border_watch", "Border Watch", PerkCategory.MILITARY, PerkKind.MINOR, class_1802.field_27070, "Watch posts report danger: being hit by a projectile grants Speed I for 8 seconds.");
    }

    private static void economic() {
        add("guild_tithe", "Guild Tithe", PerkCategory.ECONOMIC, PerkKind.MODERATE, class_1802.field_8687, "Guilds pay in kind: earning experience has a one-in-four chance to grant 1 extra experience.");
        add("minted_overtime", "Minted Overtime", PerkCategory.ECONOMIC, PerkKind.STRONG, class_1802.field_8695, "The mint rewards long labor: every fifth ore broken grants 3 experience.");
        add("market_day", "Market Day", PerkCategory.ECONOMIC, PerkKind.MINOR, class_1802.field_8733, "Market stalls open: trading with villagers grants Regeneration I for 8 seconds.");
        add("salvage_rights", "Salvage Rights", PerkCategory.ECONOMIC, PerkKind.MODERATE, class_1802.field_8782, "Nothing is wasted: killing armored mobs has a chance to drop an iron nugget.");
        add("enchanters_license", "Enchanter's License", PerkCategory.ECONOMIC, PerkKind.STRONG, class_1802.field_8657, "Licensed scholars prosper: collecting an experience orb while near an enchanting table grants 2 bonus XP.");
        add("public_ledger", "Public Ledger", PerkCategory.ECONOMIC, PerkKind.MINOR, class_1802.field_8529, "The ledgers are open: every new active policy announces its cost and remaining Policy Points.");
        add("austerity_act", "Austerity Act", PerkCategory.ECONOMIC, PerkKind.DEBUFF, class_1802.field_23983, "Austerity is imposed: subjects lose 10 percent of earned experience and refund 3 Policy Points.");
        add("blacksmith_contract", "Blacksmith Contract", PerkCategory.ECONOMIC, PerkKind.MODERATE, class_1802.field_16308, "The forges work for the realm: mining iron while holding a damaged tool repairs it by 1 durability.");
        add("fisher_auction", "Fisher Auction", PerkCategory.ECONOMIC, PerkKind.MINOR, class_1802.field_8378, "Dock auctions are sanctioned: catching fish grants Luck I for 12 seconds.");
        add("war_bonds", "War Bonds", PerkCategory.ECONOMIC, PerkKind.STRONG, class_1802.field_8845, "Wartime bonds sell fast: everyone gains 25 percent bonus XP from combat but takes 10 percent more damage.");
    }

    private static void social() {
        add("open_roads", "Open Roads Act", PerkCategory.SOCIAL, PerkKind.MODERATE, class_1802.field_8370, "The highways are cleared: sprinting on roads, stone, or planks grants Speed I.");
        add("public_clinic", "Public Clinic", PerkCategory.SOCIAL, PerkKind.STRONG, class_1802.field_8463, "The clinics open: sleeping or respawning grants Regeneration II for 15 seconds.");
        add("festival_law", "Festival Law", PerkCategory.SOCIAL, PerkKind.MINOR, class_1802.field_17534, "The realm celebrates: eating sweet food grants Jump Boost I for 12 seconds.");
        add("safe_lodging", "Safe Lodging", PerkCategory.SOCIAL, PerkKind.MINOR, class_1802.field_8789, "Inns receive funding: entering a bed clears Poison and Hunger.");
        add("courier_network", "Courier Network", PerkCategory.SOCIAL, PerkKind.MODERATE, class_1802.field_8895, "Royal couriers ride: after traveling 300 blocks, gain Speed II for 20 seconds.");
        add("night_school", "Night School", PerkCategory.SOCIAL, PerkKind.MODERATE, class_1802.field_8557, "Night schools convene: after sunset, subjects gain Night Vision while outdoors.");
        add("bread_and_circuses", "Bread and Circuses", PerkCategory.SOCIAL, PerkKind.STRONG, class_1802.field_8639, "Wartime pageantry begins: everyone gains Speed II, but max health is reduced by 2 hearts.");
        add("ration_cards", "Ration Cards", PerkCategory.SOCIAL, PerkKind.DEBUFF, class_1802.field_8407, "Rations are tightened: natural regeneration is slowed by Hunger I and refund 3 Policy Points.");
        add("civil_service", "Civil Service", PerkCategory.SOCIAL, PerkKind.MINOR, class_1802.field_8674, "Helpful clerks reduce friction: opening the policy viewer shows the king's trust and current promises.");
        add("stone_shelters", "Stone Shelters", PerkCategory.SOCIAL, PerkKind.MODERATE, class_1802.field_20412, "Public shelters stand ready: taking fall damage grants Resistance I for 8 seconds.");
    }

    private static void corruption() {
        add("crown_tax", "Crown Tax", PerkCategory.CORRUPTION, PerkKind.CORRUPTION, class_1802.field_8862, "The king claims first profit: the king gains 40 percent bonus XP while subjects lose 15 percent XP.");
        add("velvet_gaol", "Velvet Gaol", PerkCategory.CORRUPTION, PerkKind.CORRUPTION, class_1802.field_8076, "The palace is secure: the king receives Resistance II while subjects suffer Mining Fatigue I.");
        add("royal_physician", "Royal Physician", PerkCategory.CORRUPTION, PerkKind.CORRUPTION, class_1802.field_8597, "Court physicians serve one patient: the king receives Regeneration II while subjects cannot skip night.");
        add("private_armory", "Private Armory", PerkCategory.CORRUPTION, PerkKind.CORRUPTION, class_1802.field_22022, "The royal armory closes to the public: the king gains Strength II while subjects suffer Weakness I.");
        add("silken_roads", "Silken Roads", PerkCategory.CORRUPTION, PerkKind.CORRUPTION, class_1802.field_8753, "The roads bend toward the palace: the king gains Speed II while subjects suffer Slowness I.");
        add("dragon_seal", "Dragon Seal", PerkCategory.CORRUPTION, PerkKind.CORRUPTION, class_1802.field_8613, "Forbidden seals protect the throne: the king gains Fire Resistance and subjects take 10 percent more damage.");
    }

    public record BudgetResult(boolean valid, int spent, int remaining, List<String> errors) {}
}
