package com.example.kingdoms.ui;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.List;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5250;

/**
 * Centralised display strings. All user-visible text lives here.
 * Uses Minecraft's native Text API with explicit colour formatting.
 */
public final class Messages {

    private Messages() {}

    // ------------------------------------------------------------------
    // Shared UI prefix
    // ------------------------------------------------------------------

    private static final String PREFIX_RAW  = "[Kingdom] ";
    private static final class_124 COLOR_PREFIX = class_124.field_1065;
    private static final DateTimeFormatter DATE_FMT =
        DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm 'UTC'").withZone(ZoneOffset.UTC);

    public static class_5250 prefix() {
        return class_2561.method_43470(PREFIX_RAW).method_27692(COLOR_PREFIX);
    }

    public static class_5250 prefixed(class_5250 body) {
        return prefix().method_10852(body);
    }

    // ------------------------------------------------------------------
    // Status
    // ------------------------------------------------------------------

    public static class_5250 statusHeader() {
        return class_2561.method_43470("--- Kingdom Status ---").method_27695(class_124.field_1065, class_124.field_1067);
    }

    public static class_5250 rulerLine(String rulerName) {
        return class_2561.method_43470("Ruler: ").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(rulerName).method_27692(class_124.field_1068));
    }

    public static class_5250 noRuler() {
        return class_2561.method_43470("Ruler: ").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470("None").method_27692(class_124.field_1080));
    }

    public static class_5250 termEndLine(long epochMs) {
        String date = DATE_FMT.format(Instant.ofEpochMilli(epochMs));
        return class_2561.method_43470("Term ends: ").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(date).method_27692(class_124.field_1068));
    }

    public static class_5250 phaseLine(String phase) {
        return class_2561.method_43470("Phase: ").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(phase == null ? "IDLE" : phase).method_27692(class_124.field_1075));
    }

    // ------------------------------------------------------------------
    // Candidate list
    // ------------------------------------------------------------------

    public static class_5250 candidatesHeader(int count) {
        return class_2561.method_43470("=== Candidates (" + count + ") ===").method_27695(class_124.field_1065, class_124.field_1067);
    }

    public static class_5250 candidateLine(int index, String name, String slogan) {
        class_5250 line = class_2561.method_43470((index + 1) + ". ").method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(name).method_27692(class_124.field_1068));
        if (slogan != null && !slogan.isBlank()) {
            line.method_10852(class_2561.method_43470(" — " + slogan).method_27692(class_124.field_1080));
        }
        return line;
    }

    public static class_5250 noCandidates() {
        return prefixed(class_2561.method_43470("No candidates have registered yet.").method_27692(class_124.field_1080));
    }

    // ------------------------------------------------------------------
    // Vote feedback
    // ------------------------------------------------------------------

    public static class_5250 voteRecorded(String candidateName) {
        return prefixed(
            class_2561.method_43470("Vote cast for ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(candidateName).method_27692(class_124.field_1068))
                .method_10852(class_2561.method_43470(".").method_27692(class_124.field_1060))
        );
    }

    public static class_5250 alreadyVoted() {
        return prefixed(class_2561.method_43470("You have already voted in this election.").method_27692(class_124.field_1061));
    }

    public static class_5250 votingNotOpen() {
        return prefixed(class_2561.method_43470("Voting is not currently open.").method_27692(class_124.field_1061));
    }

    public static class_5250 notEnoughPlaytime(int have, int need) {
        return prefixed(
            class_2561.method_43470("You need at least " + need + " minutes of playtime to vote (you have " + have + ").").method_27692(class_124.field_1061)
        );
    }

    // ------------------------------------------------------------------
    // Candidacy
    // ------------------------------------------------------------------

    public static class_5250 registeredAsCandidate(String slogan) {
        class_5250 msg = prefixed(class_2561.method_43470("You are now a candidate!").method_27692(class_124.field_1060));
        if (slogan != null && !slogan.isBlank()) {
            msg.method_10852(class_2561.method_43470(" Slogan: " + slogan).method_27692(class_124.field_1080));
        }
        return msg;
    }

    public static class_5250 alreadyCandidate() {
        return prefixed(class_2561.method_43470("You are already registered as a candidate.").method_27692(class_124.field_1061));
    }

    public static class_5250 nominationsNotOpen() {
        return prefixed(class_2561.method_43470("Nominations are not currently open.").method_27692(class_124.field_1061));
    }

    public static class_5250 holderCannotRun() {
        return prefixed(class_2561.method_43470("The current officeholder cannot run as a candidate.").method_27692(class_124.field_1061));
    }

    public static class_5250 noActiveElection() {
        return prefixed(class_2561.method_43470("There is no active election right now.").method_27692(class_124.field_1080));
    }

    // ------------------------------------------------------------------
    // Admin feedback
    // ------------------------------------------------------------------

    public static class_5250 electionStarted() {
        return prefixed(class_2561.method_43470("Election started.").method_27692(class_124.field_1060));
    }

    public static class_5250 electionEnded() {
        return prefixed(class_2561.method_43470("Election ended and resolved.").method_27692(class_124.field_1060));
    }

    public static class_5250 rulerSet(String name) {
        return prefixed(
            class_2561.method_43470("Ruler set to ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(name).method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(".").method_27692(class_124.field_1060))
        );
    }

    public static class_5250 rulerRemoved() {
        return prefixed(class_2561.method_43470("Ruler removed; throne is vacant.").method_27692(class_124.field_1054));
    }

    public static class_5250 phaseSet(String phase) {
        return prefixed(
            class_2561.method_43470("Phase set to ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(phase).method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(".").method_27692(class_124.field_1060))
        );
    }

    public static class_5250 configReloaded() {
        return prefixed(class_2561.method_43470("Note: config is loaded once at startup and cannot be hot-reloaded.").method_27692(class_124.field_1054));
    }

    public static class_5250 orbGiven(String playerName) {
        return prefixed(
            class_2561.method_43470("Origin orb given to ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(playerName).method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(".").method_27692(class_124.field_1060))
        );
    }

    public static class_5250 originAssigned(String playerName, String originId) {
        return prefixed(
            class_2561.method_43470("Assigned origin ").method_27692(class_124.field_1060)
                .method_10852(class_2561.method_43470(originId).method_27692(class_124.field_1075))
                .method_10852(class_2561.method_43470(" to ")).method_10852(class_2561.method_43470(playerName).method_27692(class_124.field_1068)).method_10852(class_2561.method_43470(".").method_27692(class_124.field_1060))
        );
    }

    public static class_5250 debugSynced() {
        return prefixed(class_2561.method_43470("Origin sync validated for current ruler.").method_27692(class_124.field_1060));
    }

    public static class_5250 noRulerToSync() {
        return prefixed(class_2561.method_43470("No ruler currently in office.").method_27692(class_124.field_1080));
    }

    public static class_5250 error(String message) {
        return prefixed(class_2561.method_43470(message).method_27692(class_124.field_1061));
    }

    public static class_5250 playerNotFound(String name) {
        return prefixed(class_2561.method_43470("Player not found: " + name).method_27692(class_124.field_1061));
    }

    public static class_5250 noPermission() {
        return prefixed(class_2561.method_43470("You do not have permission to do that.").method_27692(class_124.field_1061));
    }

    // ------------------------------------------------------------------
    // Announcements (broadcast)
    // ------------------------------------------------------------------

    public static class_5250 announceElectionStart(String officeName) {
        return class_2561.method_43470("[KINGDOM] ").method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470("An election for " + officeName + " has begun! Nominations are now open.").method_27692(class_124.field_1054));
    }

    public static class_5250 announceVotingOpen(List<String> names) {
        class_5250 msg = class_2561.method_43470("[KINGDOM] ").method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470("Voting is now open! Candidates: ").method_27692(class_124.field_1054));
        msg.method_10852(class_2561.method_43470(String.join(", ", names)).method_27692(class_124.field_1068));
        return msg;
    }

    public static class_5250 announceWinner(String winnerName) {
        return class_2561.method_43470("[KINGDOM] ").method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470(winnerName).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" has won the election and is now the ruler!").method_27692(class_124.field_1054));
    }

    public static class_5250 announceRulerChange(String oldRuler, String newRuler) {
        if (newRuler == null) {
            // Ruler removed; throne vacant
            return class_2561.method_43470("[KINGDOM] ").method_27695(class_124.field_1065, class_124.field_1067)
                .method_10852(class_2561.method_43470("The throne is now vacant").method_27692(class_124.field_1054))
                .method_10852(oldRuler != null
                    ? class_2561.method_43470(" — " + oldRuler + "'s term has ended.").method_27692(class_124.field_1080)
                    : class_2561.method_43470(".").method_27692(class_124.field_1054));
        }
        return class_2561.method_43470("[KINGDOM] ").method_27695(class_124.field_1065, class_124.field_1067)
            .method_10852(class_2561.method_43470(newRuler).method_27692(class_124.field_1075))
            .method_10852(class_2561.method_43470(" has taken the throne").method_27692(class_124.field_1054))
            .method_10852(oldRuler != null
                ? class_2561.method_43470(" from " + oldRuler).method_27692(class_124.field_1080)
                : class_2561.method_43470("").method_27692(class_124.field_1054))
            .method_10852(class_2561.method_43470("!").method_27692(class_124.field_1054));
    }

    public static class_5250 announceRoyalDecree(String rulerName, String message) {
        return class_2561.method_43470("[ROYAL DECREE] ").method_27695(class_124.field_1064, class_124.field_1067)
            .method_10852(class_2561.method_43470(rulerName + ": ").method_27692(class_124.field_1076))
            .method_10852(class_2561.method_43470(message).method_27692(class_124.field_1068));
    }

    // ------------------------------------------------------------------
    // GUI labels (items in inventory menus)
    // ------------------------------------------------------------------

    public static class_5250 guiTitle(String name) {
        return class_2561.method_43470(name).method_27695(class_124.field_1062, class_124.field_1067);
    }

    public static class_5250 guiVoteButton() {
        return class_2561.method_43470("Vote").method_27695(class_124.field_1060, class_124.field_1067);
    }

    public static class_5250 guiViewCandidatesButton() {
        return class_2561.method_43470("View Candidates").method_27692(class_124.field_1075);
    }

    public static class_5250 guiRulerPanelButton() {
        return class_2561.method_43470("Ruler Panel").method_27695(class_124.field_1065, class_124.field_1067);
    }

    public static class_5250 guiHistoryButton() {
        return class_2561.method_43470("History").method_27692(class_124.field_1054);
    }

    public static class_5250 guiConfirmVote() {
        return class_2561.method_43470("Confirm Vote").method_27695(class_124.field_1060, class_124.field_1067);
    }

    public static class_5250 guiCancel() {
        return class_2561.method_43470("Cancel").method_27695(class_124.field_1061, class_124.field_1067);
    }

    public static class_5250 guiBroadcastSpeech() {
        return class_2561.method_43470("Broadcast Speech").method_27695(class_124.field_1076, class_124.field_1067);
    }

    public static class_5250 guiComingSoon() {
        return class_2561.method_43470("Coming Soon").method_27692(class_124.field_1080);
    }

    public static class_5250 guiPhaseNotice(String phase) {
        return class_2561.method_43470("Voting is not open (phase: " + (phase == null ? "IDLE" : phase) + ")").method_27692(class_124.field_1080);
    }

    // ------------------------------------------------------------------
    // Chat prompts
    // ------------------------------------------------------------------

    public static class_5250 speechPrompt() {
        return prefixed(
            class_2561.method_43470("Type your royal decree in chat. Your next message will be broadcast server-wide.").method_27692(class_124.field_1076)
        );
    }

    public static class_5250 speechCancelled() {
        return prefixed(class_2561.method_43470("Royal speech cancelled.").method_27692(class_124.field_1080));
    }

    // ------------------------------------------------------------------
    // Help
    // ------------------------------------------------------------------

    public static class_5250 helpHeader() {
        return class_2561.method_43470("=== Kingdom Commands ===").method_27695(class_124.field_1065, class_124.field_1067);
    }

    public static class_5250 helpLine(String cmd, String desc) {
        return class_2561.method_43470("  " + cmd).method_27692(class_124.field_1054)
            .method_10852(class_2561.method_43470(" — " + desc).method_27692(class_124.field_1080));
    }
}
