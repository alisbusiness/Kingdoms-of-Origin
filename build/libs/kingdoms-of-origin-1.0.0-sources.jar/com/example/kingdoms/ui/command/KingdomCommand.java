package com.example.kingdoms.ui.command;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.db.model.Candidate;
import com.example.kingdoms.election.ElectionException;
import com.example.kingdoms.election.ElectionPhase;
import com.example.kingdoms.election.ElectionService;
import com.example.kingdoms.origin.OfficeService;
import com.example.kingdoms.origin.OriginAdapter;
import com.example.kingdoms.origin.OriginTransferService;
import com.example.kingdoms.ui.Messages;
import com.example.kingdoms.ui.Permissions;
import com.example.kingdoms.ui.gui.GuiService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Registers all /kingdom commands using Fabric's Brigadier API.
 * Call {@link #register()} during ModInitializer.onInitialize() — before the server starts.
 */
public final class KingdomCommand {

    private final KingdomsPlugin plugin;
    private final ElectionService electionService;
    private final OfficeService officeService;
    private final OriginTransferService transferService;
    private final GuiService guiService;

    public KingdomCommand(
        KingdomsPlugin plugin,
        ElectionService electionService,
        OfficeService officeService,
        OriginTransferService transferService,
        GuiService guiService
    ) {
        this.plugin          = plugin;
        this.electionService = electionService;
        this.officeService   = officeService;
        this.transferService = transferService;
        this.guiService      = guiService;
    }

    public void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            build(dispatcher));
    }

    // ------------------------------------------------------------------
    // Command tree
    // ------------------------------------------------------------------

    private void build(CommandDispatcher<class_2168> dispatcher) {

        var kingdom = class_2170.method_9247("kingdom");

        // --- Player sub-commands ---

        kingdom.then(class_2170.method_9247("status")
            .requires(Permissions::isPlayer)
            .executes(this::cmdStatus));

        kingdom.then(class_2170.method_9247("vote")
            .requires(Permissions::isPlayer)
            .executes(this::cmdVote));

        kingdom.then(class_2170.method_9247("candidates")
            .requires(Permissions::isPlayer)
            .executes(this::cmdCandidates));

        kingdom.then(class_2170.method_9247("run")
            .requires(Permissions::isPlayer)
            .then(class_2170.method_9244("slogan", StringArgumentType.greedyString())
                .executes(ctx -> cmdRun(ctx, StringArgumentType.getString(ctx, "slogan"))))
            .executes(ctx -> cmdRun(ctx, "")));

        kingdom.then(class_2170.method_9247("ruler")
            .requires(Permissions::isPlayer)
            .executes(this::cmdRuler));

        kingdom.then(class_2170.method_9247("promise")
            .requires(Permissions::isPlayer)
            .then(class_2170.method_9244("perks", StringArgumentType.greedyString())
                .executes(ctx -> cmdPromise(ctx, StringArgumentType.getString(ctx, "perks")))));

        kingdom.then(class_2170.method_9247("setperks")
            .requires(Permissions::isPlayer)
            .then(class_2170.method_9244("perks", StringArgumentType.greedyString())
                .executes(ctx -> cmdSetPerks(ctx, StringArgumentType.getString(ctx, "perks")))));

        kingdom.then(class_2170.method_9247("help")
            .executes(this::cmdHelp));

        kingdom.then(class_2170.method_9247("menu")
            .requires(Permissions::isPlayer)
            .executes(this::cmdMenu));

        kingdom.then(class_2170.method_9247("start-election")
            .requires(Permissions::isPlayer)
            .executes(this::cmdStartElection));

        // --- Admin sub-commands ---

        var admin = class_2170.method_9247("admin")
            .requires(Permissions::isAdmin);

        admin.then(class_2170.method_9247("start-election")
            .executes(this::adminStartElection));

        admin.then(class_2170.method_9247("end-election")
            .executes(this::adminEndElection));

        admin.then(class_2170.method_9247("set-ruler")
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(ctx -> adminSetRuler(ctx, class_2186.method_9315(ctx, "player")))));

        admin.then(class_2170.method_9247("remove-ruler")
            .executes(this::adminRemoveRuler));

        admin.then(class_2170.method_9247("force-transfer")
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(ctx -> adminForceTransfer(ctx, class_2186.method_9315(ctx, "player")))));

        admin.then(class_2170.method_9247("give-orb")
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(ctx -> adminGiveOrb(ctx, class_2186.method_9315(ctx, "player")))));

        admin.then(class_2170.method_9247("set-phase")
            .then(class_2170.method_9244("phase", StringArgumentType.word())
                .executes(ctx -> adminSetPhase(ctx, StringArgumentType.getString(ctx, "phase")))));

        admin.then(class_2170.method_9247("reload")
            .executes(this::adminReload));

        admin.then(class_2170.method_9247("debug-sync")
            .executes(this::adminDebugSync));

        kingdom.then(admin);

        dispatcher.register(kingdom);
    }

    // ------------------------------------------------------------------
    // Player command handlers
    // ------------------------------------------------------------------

    private int cmdStatus(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        String phase     = officeService.getPhase();
        long   termEnd   = officeService.getTermEnd();

        src.method_45068(Messages.statusHeader());
        if (rulerUuid != null) {
            src.method_45068(Messages.rulerLine(resolveOrUuid(src, rulerUuid)));
            src.method_45068(Messages.termEndLine(termEnd));
        } else {
            src.method_45068(Messages.noRuler());
        }
        src.method_45068(Messages.phaseLine(phase));
        return 1;
    }

    private int cmdVote(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            ElectionPhase phase = ElectionPhase.fromString(officeService.getPhase());
            if (phase != ElectionPhase.VOTING) {
                player.method_7353(Messages.votingNotOpen(), false);
                return;
            }
            guiService.openCandidateList(player);
        });
    }

    private int cmdCandidates(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                try {
                    var candidates = electionService.getCandidates(election.getId());
                    src.method_45068(Messages.candidatesHeader(candidates.size()));
                    for (int i = 0; i < candidates.size(); i++) {
                        var c    = candidates.get(i);
                        String name = resolveOrUuid(src, c.getPlayerUuid());
                        src.method_45068(Messages.candidateLine(i, name, c.getSlogan()));
                    }
                    if (candidates.isEmpty()) src.method_45068(Messages.noCandidates());
                } catch (SQLException e) {
                    src.method_45068(Messages.error("Could not load candidates."));
                }
            }, () -> src.method_45068(Messages.noActiveElection()));
        } catch (SQLException e) {
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int cmdRun(CommandContext<class_2168> ctx, String slogan) {
        return withPlayer(ctx, player -> {
            try {
                String officeId = plugin.getConfig().office().id();
                electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                    try {
                        electionService.registerCandidate(election.getId(), player.method_5845(), slogan);
                        player.method_7353(Messages.registeredAsCandidate(slogan), false);
                    } catch (ElectionException e) {
                        String msg = e.getMessage();
                        if (msg.contains("already a candidate")) {
                            player.method_7353(Messages.alreadyCandidate(), false);
                        } else if (msg.contains("Nominations are closed")) {
                            player.method_7353(Messages.nominationsNotOpen(), false);
                        } else if (msg.contains("cannot run")) {
                            player.method_7353(Messages.holderCannotRun(), false);
                        } else {
                            player.method_7353(Messages.error(msg), false);
                        }
                    } catch (SQLException e) {
                        KingdomsPlugin.LOGGER.error("Register candidate failed", e);
                        player.method_7353(Messages.error("A server error occurred."), false);
                    }
                }, () -> player.method_7353(Messages.noActiveElection(), false));
            } catch (SQLException e) {
                KingdomsPlugin.LOGGER.error("Election lookup failed", e);
                player.method_7353(Messages.error("A server error occurred."), false);
            }
        });
    }

    private int cmdRuler(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        if (rulerUuid == null) {
            src.method_45068(Messages.noRuler());
        } else {
            src.method_45068(Messages.rulerLine(resolveOrUuid(src, rulerUuid)));
            src.method_45068(Messages.termEndLine(officeService.getTermEnd()));
            src.method_45068(Messages.phaseLine(officeService.getPhase()));
            String activePerks = officeService.getActivePerks();
            if (activePerks != null && !activePerks.isBlank()) {
                src.method_45068(net.minecraft.class_2561.method_43470("Active Perks: " + activePerks).method_27692(net.minecraft.class_124.field_1075));
            }
        }
        return 1;
    }

    private int cmdPromise(CommandContext<class_2168> ctx, String perks) {
        return withPlayer(ctx, player -> {
            try {
                String officeId = plugin.getConfig().office().id();
                electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                    try {
                        var candidateOpt = plugin.getPersistence().candidates().findByElectionAndPlayer(election.getId(), player.method_5845());
                        if (candidateOpt.isPresent()) {
                            var candidate = candidateOpt.get();
                            candidate.setPromisedPerks(perks);
                            plugin.getPersistence().candidates().delete(candidate.getId()); // Delete and re-insert to update
                            plugin.getPersistence().candidates().insert(candidate);
                            player.method_7353(net.minecraft.class_2561.method_43470("Promised perks updated to: " + perks).method_27692(net.minecraft.class_124.field_1060), false);
                        } else {
                            player.method_7353(net.minecraft.class_2561.method_43470("You must /kingdom run first.").method_27692(net.minecraft.class_124.field_1061), false);
                        }
                    } catch (SQLException e) {
                        player.method_7353(Messages.error("A server error occurred."), false);
                    }
                }, () -> player.method_7353(Messages.noActiveElection(), false));
            } catch (SQLException e) {
                player.method_7353(Messages.error("A server error occurred."), false);
            }
        });
    }

    private int cmdSetPerks(CommandContext<class_2168> ctx, String perks) {
        return withPlayer(ctx, player -> {
            String rulerUuid = officeService.getRuler();
            if (rulerUuid == null || !rulerUuid.equals(player.method_5845())) {
                player.method_7353(net.minecraft.class_2561.method_43470("Only the King can set perks!").method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }
            if (officeService.getActivePerks() != null) {
                player.method_7353(net.minecraft.class_2561.method_43470("Perks have already been set for this term!").method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }
            
            try {
                officeService.setActivePerks(perks);
                player.method_7353(net.minecraft.class_2561.method_43470("Active perks set to: " + perks).method_27692(net.minecraft.class_124.field_1060), false);
                
                // Grant powers to all players online
                MinecraftServer server = ctx.getSource().method_9211();
                for (String perk : perks.split("[,\\s]+")) {
                    if (perk.isBlank()) continue;
                    String powerId = perk.contains(":") ? perk : "kingdom:perks/" + perk;
                    server.method_3734().method_44252(server.method_3739(), "power grant @a " + powerId);
                }
            } catch (SQLException e) {
                player.method_7353(Messages.error("Failed to save active perks."), false);
            }
        });
    }

    private int cmdHelp(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        src.method_45068(Messages.helpHeader());
        src.method_45068(Messages.helpLine("/kingdom status",     "Show current ruler and election phase"));
        src.method_45068(Messages.helpLine("/kingdom vote",       "Open the voting GUI"));
        src.method_45068(Messages.helpLine("/kingdom candidates", "List current candidates in chat"));
        src.method_45068(Messages.helpLine("/kingdom run [slogan]", "Register your candidacy"));
        src.method_45068(Messages.helpLine("/kingdom promise <perks>", "Set your promised perks"));
        src.method_45068(Messages.helpLine("/kingdom setperks <perks>", "King only: lock in active perks"));
        src.method_45068(Messages.helpLine("/kingdom ruler",      "Show ruler details"));
        src.method_45068(Messages.helpLine("/kingdom menu",       "Open the main kingdom GUI"));
        if (Permissions.isAdmin(src)) {
            src.method_45068(Messages.helpLine("/kingdom admin ...", "Admin commands (you have access)"));
        }
        return 1;
    }

    private int cmdMenu(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, guiService::openMainMenu);
    }

    private int cmdStartElection(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            String rulerUuid = officeService.getRuler();
            if (rulerUuid == null || !rulerUuid.equals(player.method_5845())) {
                player.method_7353(net.minecraft.class_2561.method_43470("Only the King can start elections!").method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }
            try {
                plugin.startElectionAndSchedule(plugin.getConfig().office().id());
                player.method_7353(Messages.electionStarted(), false);
            } catch (ElectionException e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            } catch (SQLException e) {
                KingdomsPlugin.LOGGER.error("Start election failed", e);
                player.method_7353(Messages.error("A server error occurred."), false);
            }
        });
    }

    // ------------------------------------------------------------------
    // Admin command handlers
    // ------------------------------------------------------------------

    private int adminStartElection(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            plugin.startElectionAndSchedule(plugin.getConfig().office().id());
            src.method_45068(Messages.electionStarted());
        } catch (ElectionException e) {
            src.method_45068(Messages.error(e.getMessage()));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Start election failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminEndElection(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                try {
                    plugin.getScheduleService().forceAdvancePhase(election.getId());
                    src.method_45068(Messages.electionEnded());
                } catch (Exception e) {
                    src.method_45068(Messages.error("Failed to end election: " + e.getMessage()));
                }
            }, () -> src.method_45068(Messages.noActiveElection()));
        } catch (SQLException e) {
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminSetRuler(CommandContext<class_2168> ctx, class_3222 target) {
        class_2168 src = ctx.getSource();
        try {
            officeService.assignRuler(target.method_5667());
            src.method_45068(Messages.rulerSet(target.method_5477().getString()));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Set ruler failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminRemoveRuler(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            officeService.removeRuler(OfficeService.RemovalReason.FORCED);
            src.method_45068(Messages.rulerRemoved());
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Remove ruler failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminForceTransfer(CommandContext<class_2168> ctx, class_3222 target) {
        class_2168 src = ctx.getSource();
        String currentRulerUuid = officeService.getRuler();
        if (currentRulerUuid == null) {
            // No current ruler — just assign
            try {
                officeService.assignRuler(target.method_5667());
                src.method_45068(Messages.rulerSet(target.method_5477().getString()));
            } catch (SQLException e) {
                src.method_45068(Messages.error("A server error occurred."));
            }
            return 1;
        }
        try {
            transferService.transferOffice(UUID.fromString(currentRulerUuid), target.method_5667());
            src.method_45068(Messages.rulerSet(target.method_5477().getString()));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Force transfer failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminGiveOrb(CommandContext<class_2168> ctx, class_3222 target) {
        class_2168 src = ctx.getSource();
        try {
            transferService.giveOriginOrb(target);
            src.method_45068(Messages.orbGiven(target.method_5477().getString()));
        } catch (Exception e) {
            KingdomsPlugin.LOGGER.error("Give orb failed", e);
            src.method_45068(Messages.error("Failed to give orb: " + e.getMessage()));
        }
        return 1;
    }

    private int adminSetPhase(CommandContext<class_2168> ctx, String phase) {
        class_2168 src = ctx.getSource();
        try {
            ElectionPhase.valueOf(phase.toUpperCase());
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                try {
                    election.setStatus(phase.toUpperCase());
                    plugin.getPersistence().elections().update(election);
                    src.method_45068(Messages.phaseSet(phase.toUpperCase()));
                } catch (SQLException e) {
                    src.method_45068(Messages.error("A server error occurred."));
                }
            }, () -> src.method_45068(Messages.noActiveElection()));
        } catch (IllegalArgumentException e) {
            src.method_45068(Messages.error("Unknown phase: " + phase));
        } catch (SQLException e) {
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminReload(CommandContext<class_2168> ctx) {
        plugin.reloadConfig();
        ctx.getSource().method_45068(Messages.configReloaded());
        return 1;
    }

    private int adminDebugSync(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        if (rulerUuid == null) {
            src.method_45068(Messages.noRulerToSync());
            return 1;
        }
        class_3222 ruler = src.method_9211().method_3760().method_14602(UUID.fromString(rulerUuid));
        if (ruler != null) {
            transferService.validateSync(ruler);
            src.method_45068(Messages.debugSynced());
        } else {
            src.method_45068(Messages.error("Ruler is offline; sync will apply on next login."));
        }
        return 1;
    }

    // ------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------

    /** Runs an action requiring a player source; sends an error and returns 0 if not a player. */
    private int withPlayer(CommandContext<class_2168> ctx, java.util.function.Consumer<class_3222> action) {
        if (!(ctx.getSource().method_9228() instanceof class_3222 player)) {
            ctx.getSource().method_45068(Messages.error("This command can only be used by players."));
            return 0;
        }
        action.accept(player);
        return 1;
    }

    private String resolveOrUuid(class_2168 src, String uuid) {
        try {
            class_3222 online = src.method_9211().method_3760().method_14602(UUID.fromString(uuid));
            if (online != null) return online.method_5477().getString();
            return plugin.getPersistence().players().findByUuid(uuid)
                .map(p -> p.getUsername() != null ? p.getUsername() : uuid)
                .orElse(uuid);
        } catch (Exception e) {
            return uuid;
        }
    }
}
