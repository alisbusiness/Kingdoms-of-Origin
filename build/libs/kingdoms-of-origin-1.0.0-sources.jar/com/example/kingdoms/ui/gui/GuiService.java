package com.example.kingdoms.ui.gui;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.db.model.Candidate;
import com.example.kingdoms.election.ElectionException;
import com.example.kingdoms.election.ElectionPhase;
import com.example.kingdoms.election.ElectionService;
import com.example.kingdoms.origin.OfficeService;
import com.example.kingdoms.ui.AnnouncementService;
import com.example.kingdoms.ui.Messages;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;
import net.minecraft.server.MinecraftServer;
import java.sql.SQLException;
import java.util.List;
import java.util.UUID;

/**
 * Builds and opens inventory GUI menus for political interactions.
 * Each open* method constructs an inventory, populates it, and opens it for the player.
 */
public final class GuiService {

    private final ElectionService electionService;
    private final OfficeService officeService;
    private final AnnouncementService announcementService;
    private final KingdomsPlugin plugin;

    public GuiService(
        ElectionService electionService,
        OfficeService officeService,
        AnnouncementService announcementService,
        KingdomsPlugin plugin
    ) {
        this.electionService    = electionService;
        this.officeService      = officeService;
        this.announcementService = announcementService;
        this.plugin             = plugin;
    }

    // ------------------------------------------------------------------
    // a. Main politics menu
    // ------------------------------------------------------------------

    public void openMainMenu(class_3222 player) {
        class_1277 inv = new class_1277(9 * 3);
        String rulerUuid  = officeService.getRuler();
        String phase      = officeService.getPhase();
        long   termEnd    = officeService.getTermEnd();

        // Slot 4 — current ruler skull
        if (rulerUuid != null) {
            MinecraftServer server = player.method_5682();
            class_3222 rulerPlayer = server != null
                ? server.method_3760().method_14602(UUID.fromString(rulerUuid)) : null;
            String rulerName = rulerPlayer != null ? rulerPlayer.method_5477().getString() : rulerUuid;
            inv.method_5447(4, headStack(rulerUuid, rulerName,
                List.of(Messages.termEndLine(termEnd), Messages.phaseLine(phase))));
        } else {
            inv.method_5447(4, namedStack(class_1802.field_8077,
                class_2561.method_43470("No Ruler").method_27692(class_124.field_1080),
                List.of(class_2561.method_43470("The throne is vacant.").method_27692(class_124.field_1063))));
        }

        // Slot 11 — Vote button
        ElectionPhase electionPhase = ElectionPhase.fromString(phase);
        if (electionPhase == ElectionPhase.VOTING) {
            inv.method_5447(11, namedStack(class_1802.field_8581,
                Messages.guiVoteButton(),
                List.of(class_2561.method_43470("Click to see candidates and vote.").method_27692(class_124.field_1080))));
        } else {
            inv.method_5447(11, namedStack(class_1802.field_8871,
                Messages.guiVoteButton(),
                List.of(Messages.guiPhaseNotice(phase))));
        }

        // Slot 13 — View Candidates
        inv.method_5447(13, namedStack(class_1802.field_8529,
            Messages.guiViewCandidatesButton(),
            List.of(class_2561.method_43470("See who is running.").method_27692(class_124.field_1080))));

        // Slot 15 — Ruler Panel (only for current ruler)
        if (rulerUuid != null && rulerUuid.equals(player.method_5845())) {
            inv.method_5447(15, namedStack(class_1802.field_8862,
                Messages.guiRulerPanelButton(),
                List.of(class_2561.method_43470("Access your administrative panel.").method_27692(class_124.field_1080))));
        }

        // Slot 17 — History placeholder
        inv.method_5447(17, namedStack(class_1802.field_8674,
            Messages.guiHistoryButton(),
            List.of(class_2561.method_43470("View kingdom history.").method_27692(class_124.field_1080),
                    class_2561.method_43470("(Coming soon)").method_27692(class_124.field_1063))));

        openScreen(player, inv, 3, Messages.guiTitle("Kingdom Politics"), (slot, clicker) -> {
            switch (slot) {
                case 11 -> {
                    if (ElectionPhase.fromString(officeService.getPhase()) == ElectionPhase.VOTING) {
                        openCandidateList(clicker);
                    } else {
                        clicker.method_7353(Messages.votingNotOpen(), false);
                    }
                }
                case 13 -> openCandidateList(clicker);
                case 15 -> {
                    if (officeService.getRuler() != null
                            && officeService.getRuler().equals(clicker.method_5845())) {
                        openRulerPanel(clicker);
                    }
                }
                default -> {}
            }
        });
    }

    // ------------------------------------------------------------------
    // b. Candidate list menu
    // ------------------------------------------------------------------

    public void openCandidateList(class_3222 player) {
        List<Candidate> candidates = loadCandidates();
        int rows = Math.max(1, (int) Math.ceil((candidates.size() + 1) / 9.0));
        rows = Math.min(rows, 6);

        class_1277 inv = new class_1277(rows * 9);
        for (int i = 0; i < candidates.size() && i < rows * 9; i++) {
            Candidate c = candidates.get(i);
            String name   = resolvePlayerName(player, c.getPlayerUuid());
            String slogan = c.getSlogan();
            List<class_2561> lore = slogan != null && !slogan.isBlank()
                ? List.of(class_2561.method_43470(slogan).method_27692(class_124.field_1080))
                : List.of();
            inv.method_5447(i, headStack(c.getPlayerUuid(), name, lore));
        }

        if (candidates.isEmpty()) {
            inv.method_5447(4, namedStack(class_1802.field_8077,
                class_2561.method_43470("No candidates yet.").method_27692(class_124.field_1080),
                List.of()));
        }

        openScreen(player, inv, rows, Messages.guiTitle("Candidates"), (slot, clicker) -> {
            if (slot < candidates.size()) {
                openVoteConfirmation(clicker, candidates.get(slot));
            }
        });
    }

    // ------------------------------------------------------------------
    // c. Vote confirmation menu
    // ------------------------------------------------------------------

    public void openVoteConfirmation(class_3222 player, Candidate candidate) {
        class_1277 inv = new class_1277(9);

        String name = resolvePlayerName(player, candidate.getPlayerUuid());
        String slogan = candidate.getSlogan();
        List<class_2561> lore = slogan != null && !slogan.isBlank()
            ? List.of(class_2561.method_43470(slogan).method_27692(class_124.field_1056))
            : List.of();

        inv.method_5447(4, headStack(candidate.getPlayerUuid(), name, lore));

        inv.method_5447(2, namedStack(class_1802.field_8581,
            Messages.guiConfirmVote(),
            List.of(class_2561.method_43470("Confirm your vote for " + name + ".").method_27692(class_124.field_1080))));

        inv.method_5447(6, namedStack(class_1802.field_8879,
            Messages.guiCancel(),
            List.of(class_2561.method_43470("Go back.").method_27692(class_124.field_1080))));

        openScreen(player, inv, 1, Messages.guiTitle("Confirm Vote"), (slot, clicker) -> {
            if (slot == 2) {
                clicker.method_7346();
                castVoteFor(clicker, candidate);
            } else if (slot == 6) {
                clicker.method_7346();
                openCandidateList(clicker);
            }
        });
    }

    // ------------------------------------------------------------------
    // d. Ruler panel menu
    // ------------------------------------------------------------------

    public void openRulerPanel(class_3222 player) {
        if (!player.method_5845().equals(officeService.getRuler())) {
            player.method_7353(Messages.noPermission(), false);
            return;
        }

        class_1277 inv = new class_1277(9 * 3);
        String rulerName = player.method_5477().getString();
        long   termEnd   = officeService.getTermEnd();
        String originId  = plugin.getConfig().originMode().kingOriginId();

        // Slot 4 — ruler info skull
        inv.method_5447(4, headStack(player.method_5845(), rulerName,
            List.of(
                Messages.termEndLine(termEnd),
                class_2561.method_43470("Origin: " + originId).method_27692(class_124.field_1075)
            )));

        // Slot 11 — Broadcast Speech
        inv.method_5447(11, namedStack(class_1802.field_8407,
            Messages.guiBroadcastSpeech(),
            List.of(class_2561.method_43470("Broadcast a message to the entire server.").method_27692(class_124.field_1080))));

        // Placeholder decree slots 13, 14, 15, 16
        for (int slot : new int[]{13, 14, 15, 16}) {
            inv.method_5447(slot, namedStack(class_1802.field_8871,
                Messages.guiComingSoon(),
                List.of(class_2561.method_43470("Future decree options.").method_27692(class_124.field_1063))));
        }

        openScreen(player, inv, 3, Messages.guiTitle("Ruler Panel"), (slot, clicker) -> {
            if (slot == 11) {
                clicker.method_7346();
                plugin.getEventListeners().setPendingSpeech(clicker.method_5667());
                clicker.method_7353(Messages.speechPrompt(), false);
            }
        });
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private void openScreen(
        class_3222 player,
        class_1277 inv,
        int rows,
        class_2561 title,
        java.util.function.BiConsumer<Integer, class_3222> clickHandler
    ) {
        player.method_17355(new class_747(
            (syncId, playerInv, p) -> new KingdomScreenHandler(
                syncId, playerInv, inv, rows,
                (slot, entity) -> {
                    if (entity instanceof class_3222 sp) clickHandler.accept(slot, sp);
                }
            ),
            title
        ));
    }

    private void castVoteFor(class_3222 player, Candidate candidate) {
        try {
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                int playtimeTicks = player.method_14248()
                    .method_15025(net.minecraft.class_3468.field_15419.method_14956(net.minecraft.class_3468.field_15417));
                int playtimeMinutes = playtimeTicks / 20 / 60;

                try {
                    electionService.castVote(election.getId(), player.method_5845(),
                        candidate.getPlayerUuid(), playtimeMinutes);
                    String name = resolvePlayerName(player, candidate.getPlayerUuid());
                    player.method_7353(Messages.voteRecorded(name), false);
                } catch (ElectionException e) {
                    player.method_7353(Messages.error(e.getMessage()), false);
                } catch (SQLException e) {
                    KingdomsPlugin.LOGGER.error("Vote failed", e);
                    player.method_7353(Messages.error("A server error occurred."), false);
                }
            }, () -> player.method_7353(Messages.noActiveElection(), false));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Vote lookup failed", e);
            player.method_7353(Messages.error("A server error occurred."), false);
        }
    }

    private List<Candidate> loadCandidates() {
        try {
            String officeId = plugin.getConfig().office().id();
            return electionService.getCurrentElection(officeId)
                .map(election -> {
                    try { return electionService.getCandidates(election.getId()); }
                    catch (SQLException e) { return List.<Candidate>of(); }
                })
                .orElse(List.of());
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Failed to load candidates", e);
            return List.of();
        }
    }

    private String resolvePlayerName(class_3222 requester, String uuid) {
        MinecraftServer server = requester.method_5682();
        if (server == null) return uuid;
        try {
            class_3222 online = server.method_3760().method_14602(UUID.fromString(uuid));
            if (online != null) return online.method_5477().getString();
            // Fall back to DB username
            return plugin.getPersistence().players().findByUuid(uuid)
                .map(p -> p.getUsername() != null ? p.getUsername() : uuid)
                .orElse(uuid);
        } catch (Exception e) {
            return uuid;
        }
    }

    // ------------------------------------------------------------------
    // Item builders
    // ------------------------------------------------------------------

    /** Creates an ItemStack with a custom name and lore. */
    private static class_1799 namedStack(net.minecraft.class_1792 item, class_2561 name, List<class_2561> lore) {
        class_1799 stack = new class_1799(item);
        stack.method_7977(name);
        if (!lore.isEmpty()) addLore(stack, lore);
        return stack;
    }

    /** Creates a PLAYER_HEAD with the given owner UUID and display name. */
    private static class_1799 headStack(String ownerUuid, String displayName, List<class_2561> lore) {
        class_1799 stack = new class_1799(class_1802.field_8575);
        stack.method_7977(class_2561.method_43470(displayName).method_27692(class_124.field_1054));

        class_2487 nbt = stack.method_7948();
        class_2487 skullOwner = new class_2487();
        skullOwner.method_10582("Name", displayName);
        try {
            UUID uuid = UUID.fromString(ownerUuid);
            skullOwner.method_10566("Id", new class_2495(uuidToIntArray(uuid)));
        } catch (IllegalArgumentException ignored) {}
        nbt.method_10566("SkullOwner", skullOwner);

        if (!lore.isEmpty()) addLore(stack, lore);
        return stack;
    }

    private static void addLore(class_1799 stack, List<class_2561> lore) {
        class_2499 loreList = new class_2499();
        for (class_2561 line : lore) {
            loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(line)));
        }
        stack.method_7911("display").method_10566("Lore", loreList);
    }

    private static int[] uuidToIntArray(UUID uuid) {
        long msb = uuid.getMostSignificantBits();
        long lsb = uuid.getLeastSignificantBits();
        return new int[]{(int) (msb >> 32), (int) msb, (int) (lsb >> 32), (int) lsb};
    }
}
