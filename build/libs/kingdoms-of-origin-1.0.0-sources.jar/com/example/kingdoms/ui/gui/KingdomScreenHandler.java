package com.example.kingdoms.ui.gui;

import java.util.function.BiConsumer;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1707;
import net.minecraft.class_1713;
import net.minecraft.class_1799;
import net.minecraft.class_3917;

/**
 * A GUI screen handler backed by a SimpleInventory with an arbitrary click callback.
 * Renders as a standard chest (the client needs no custom code).
 * All slot interactions within the container are routed to the provided callback;
 * item movement in/out of the container is blocked.
 */
public final class KingdomScreenHandler extends class_1707 {

    private final BiConsumer<Integer, class_1657> clickHandler;

    public KingdomScreenHandler(
        int syncId,
        class_1661 playerInventory,
        class_1263 inventory,
        int rows,
        BiConsumer<Integer, class_1657> clickHandler
    ) {
        super(typeForRows(rows), syncId, playerInventory, inventory, rows);
        this.clickHandler = clickHandler;
    }

    @Override
    public void method_7593(int slotIndex, int button, class_1713 actionType, class_1657 player) {
        if (slotIndex >= 0 && slotIndex < method_7629().method_5439()) {
            // Route button clicks to the callback; ignore drags / drops.
            if (actionType == class_1713.field_7790 || actionType == class_1713.field_7794) {
                clickHandler.accept(slotIndex, player);
            }
            return; // Block all item movement out of container
        }
        // Let the player interact with their own inventory normally.
        super.method_7593(slotIndex, button, actionType, player);
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slot) {
        return class_1799.field_8037; // Prevent shift-click transfers
    }

    @Override
    public boolean method_7597(class_1657 player) {
        return true;
    }

    private static class_3917<?> typeForRows(int rows) {
        return switch (rows) {
            case 1 -> class_3917.field_18664;
            case 2 -> class_3917.field_18665;
            case 4 -> class_3917.field_18666;
            case 5 -> class_3917.field_18667;
            case 6 -> class_3917.field_17327;
            default -> class_3917.field_17326;
        };
    }
}
