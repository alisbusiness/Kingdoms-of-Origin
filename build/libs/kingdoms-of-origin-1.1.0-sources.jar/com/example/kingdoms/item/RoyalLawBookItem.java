package com.example.kingdoms.item;

import com.example.kingdoms.db.model.Law;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;

public final class RoyalLawBookItem {
    private static final String LAW_BOOK_MARKER = "KingdomRoyalLawBook";
    private static final String LAW_VERSION = "KingdomLawVersion";
    private static final int LAWS_PER_PAGE = 8;

    private RoyalLawBookItem() {}

    public static class_1799 createStack(long version, List<Law> laws) {
        class_1799 stack = new class_1799(class_1802.field_8360);
        writeBookNbt(stack, version, laws);
        return stack;
    }

    private static void writeBookNbt(class_1799 stack, long version, List<Law> laws) {
        class_2487 nbt = stack.method_7948();
        nbt.method_10556(LAW_BOOK_MARKER, true);
        nbt.method_10544(LAW_VERSION, version);
        nbt.method_10582("title", "Royal Law Book");
        nbt.method_10582("author", "The Crown");
        nbt.method_10569("generation", 0);
        nbt.method_10556("resolved", true);
        nbt.method_10566("pages", pages(laws));
    }

    private static class_2499 pages(List<Law> laws) {
        class_2499 pages = new class_2499();
        if (laws.isEmpty()) {
            pages.add(class_2519.method_23256(class_2561.class_2562.method_10867(class_2561.method_43470("Royal Law Book\n\nNo laws have been written yet."))));
            return pages;
        }

        List<String> current = new ArrayList<>();
        for (Law law : laws) {
            current.add(law.getPosition() + ". " + law.getText());
            if (current.size() >= LAWS_PER_PAGE) {
                pages.add(page(current));
                current.clear();
            }
        }
        if (!current.isEmpty()) pages.add(page(current));
        return pages;
    }

    private static class_2519 page(List<String> lines) {
        return class_2519.method_23256(class_2561.class_2562.method_10867(class_2561.method_43470("Royal Law Book\n\n" + String.join("\n\n", lines))));
    }
}
