package com.example.kingdoms.perk;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.origin.OfficeService;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.player.AttackEntityCallback;
import net.fabricmc.fabric.api.event.player.PlayerBlockBreakEvents;
import net.fabricmc.fabric.api.event.player.UseBlockCallback;
import net.fabricmc.fabric.api.event.player.UseEntityCallback;
import net.fabricmc.fabric.api.event.player.UseItemCallback;
import net.minecraft.class_124;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1271;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1542;
import net.minecraft.class_1588;
import net.minecraft.class_1646;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7923;
import net.minecraft.server.MinecraftServer;
import java.sql.SQLException;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PerkService {
    private final KingdomsPlugin plugin;
    private final OfficeService officeService;
    private final Random random = new Random();
    private final Set<String> active = ConcurrentHashMap.newKeySet();
    private final Set<UUID> lowHealthCooldown = ConcurrentHashMap.newKeySet();
    private int tickCounter;

    public PerkService(KingdomsPlugin plugin, OfficeService officeService) {
        this.plugin = plugin;
        this.officeService = officeService;
        reloadActive();
    }

    public void registerEvents() {
        PlayerBlockBreakEvents.AFTER.register((world, player, pos, state, blockEntity) -> {
            if (!world.field_9236 && player instanceof class_3222 sp) onBreakBlock(sp, state);
        });
        AttackEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.field_9236 && player instanceof class_3222 sp) onAttack(sp, entity);
            return class_1269.field_5811;
        });
        ServerLivingEntityEvents.ALLOW_DAMAGE.register((entity, source, amount) -> {
            if (entity instanceof class_3222 sp) onDamaged(sp, source.method_5529(), amount);
            return true;
        });
        UseItemCallback.EVENT.register((player, world, hand) -> {
            if (!world.field_9236 && player instanceof class_3222 sp) onUseItem(sp, hand);
            return class_1271.method_22430(player.method_5998(hand));
        });
        UseBlockCallback.EVENT.register((player, world, hand, hitResult) -> {
            if (!world.field_9236 && player instanceof class_3222 sp) onUseBlock(sp, world.method_8320(hitResult.method_17777()).method_26204());
            return class_1269.field_5811;
        });
        UseEntityCallback.EVENT.register((player, world, hand, entity, hitResult) -> {
            if (!world.field_9236 && player instanceof class_3222 sp && entity instanceof class_1646) {
                plugin.getTreasuryService().collectTax(sp, "trade", 1);
            }
            return class_1269.field_5811;
        });
        ServerTickEvents.END_SERVER_TICK.register(this::onTick);
    }

    public void reloadActive() {
        active.clear();
        active.addAll(PerkRegistry.parseIds(officeService.getActivePerks()));
    }

    public boolean isActive(String id) {
        return active.contains(id);
    }

    public List<String> activeIds() {
        return List.copyOf(active);
    }

    public int remainingPoints(List<String> selected) {
        return PerkRegistry.validateBudget(selected).remaining();
    }

    public ApplyResult activate(class_3222 ruler, List<String> rawIds) throws SQLException {
        List<String> ids = rawIds.stream().map(PerkRegistry::normalize).distinct().toList();
        PerkRegistry.BudgetResult budget = PerkRegistry.validateBudget(ids);
        if (!budget.valid()) return new ApplyResult(false, String.join(" ", budget.errors()));
        if (!ruler.method_5845().equals(officeService.getRuler())) {
            return new ApplyResult(false, "Only the king may enact policies.");
        }

        String encoded = PerkRegistry.serialize(ids);
        officeService.setActivePerks(encoded);
        reloadActive();
        comparePromises(ruler, ids);
        MinecraftServer server = ruler.method_5682();
        if (server != null) {
            server.method_3760().method_43514(class_2561.method_43470(
                ruler.method_5477().getString() + " enacted " + ids.size() + " kingdom policies. " +
                    budget.remaining() + " Policy Points remain."
            ).method_27692(class_124.field_1065), false);
        }
        return new ApplyResult(true, "Policies enacted. Remaining Policy Points: " + budget.remaining());
    }

    private void comparePromises(class_3222 ruler, List<String> enacted) throws SQLException {
        String officeId = plugin.getConfig().office().id();
        var electionOpt = plugin.getPersistence().elections().findMostRecentCompletedByOfficeId(officeId);
        if (electionOpt.isEmpty()) return;
        long electionId = electionOpt.get().getId();
        var candidateOpt = plugin.getPersistence().candidates().findByElectionAndPlayer(electionId, ruler.method_5845());
        if (candidateOpt.isEmpty()) return;
        Set<String> enactedSet = new HashSet<>(enacted);
        for (String promise : PerkRegistry.parseIds(candidateOpt.get().getPromisedPerks())) {
            boolean honored = enactedSet.contains(promise);
            plugin.getPersistence().trust().adjust(ruler.method_5845(), honored ? 2 : -8);
            plugin.getPersistence().trust().addHistory(ruler.method_5845(), electionId, promise, PerkRegistry.serialize(enacted), honored);
            if (!honored && ruler.method_5682() != null) {
                PerkDefinition perk = PerkRegistry.find(promise).orElse(null);
                String name = perk != null ? perk.name() : promise;
                ruler.method_5682().method_3760().method_43514(class_2561.method_43470(
                    "Broken promise: " + ruler.method_5477().getString() + " promised " + name + " but did not enact it."
                ).method_27692(class_124.field_1061), false);
            }
        }
    }

    private void onBreakBlock(class_3222 player, class_2680 state) {
        class_2248 block = state.method_26204();
        if (block == class_2246.field_10442 || block == class_2246.field_29029) {
            plugin.getTreasuryService().collectTax(player, "resource", 1);
        }
        if (isActive("stone_covenant") && block == class_2246.field_10340 && player.method_23318() < 32) effect(player, class_1294.field_5917, 240, 0);
        if (isActive("deep_levy") && isOre(block) && block.method_9518().getString().contains("Deepslate")) {
            effect(player, class_1294.field_5917, 200, 1);
            xp(player, 1);
        }
        if (isActive("minted_overtime") && isOre(block) && random.nextInt(5) == 0) xp(player, 3);
        if (isActive("iron_mandate") && (block == class_2246.field_10212 || block == class_2246.field_29027 || block == class_2246.field_27120 || block == class_2246.field_29221) && random.nextInt(3) == 0) {
            drop(player, block == class_2246.field_27120 || block == class_2246.field_29221 ? "minecraft:raw_copper" : "minecraft:raw_iron", 1);
        }
        if (isActive("charcoal_charter") && isLog(block) && random.nextInt(4) == 0) drop(player, "minecraft:charcoal", 1);
        if (isActive("timber_quota") && isLog(block) && random.nextInt(10) == 0) {
            drop(player, "minecraft:stick", 2);
            effect(player, class_1294.field_5917, 300, 1);
        }
        if (isActive("green_commons") && block.method_9518().getString().contains("Leaves") && random.nextInt(5) == 0) drop(player, "minecraft:apple", 1);
        if (isActive("breadline") && isCrop(block)) player.method_7344().method_7585(1, 0.2f);
        if (isActive("canal_act") && player.method_5637()) effect(player, class_1294.field_5900, 160, 0);
        if (isActive("quarry_whistle") && (block == class_2246.field_10418 || block == class_2246.field_10080 || block == class_2246.field_10090)) {
            player.method_37908().method_18456().stream().filter(p -> p.method_5739(player) < 12).forEach(p -> effect((class_3222) p, class_1294.field_5917, 160, 0));
        }
        if (isActive("blacksmith_contract") && (block == class_2246.field_10212 || block == class_2246.field_29027)) {
            class_1799 tool = player.method_6047();
            if (tool.method_7986()) tool.method_7974(Math.max(0, tool.method_7919() - 1));
        }
    }

    private void onAttack(class_3222 player, class_1297 target) {
        if (target instanceof class_1588) {
            if (isActive("peoples_blade")) effect(player, class_1294.field_5910, 200, 0);
            if (isActive("monster_bounty") && !isActive("draft_notice")) xp(player, 1);
            if (isActive("war_bonds")) xp(player, 1);
        }
        if (isActive("private_armory") && isKing(player)) effect(player, class_1294.field_5910, 80, 1);
    }

    private void onDamaged(class_3222 player, class_1297 attacker, float amount) {
        if (isActive("shield_wall_decree") && player.method_6039()) effect(player, class_1294.field_5907, 120, 0);
        if (isActive("last_stand_clause") && player.method_6032() <= 10.0f && lowHealthCooldown.add(player.method_5667())) {
            effect(player, class_1294.field_5907, 160, 1);
            player.method_5682().execute(() -> {});
        }
        if (isActive("border_watch") && attacker != null && attacker.method_5864().method_5897().getString().contains("Arrow")) effect(player, class_1294.field_5904, 160, 0);
        if (isActive("stone_shelters")) effect(player, class_1294.field_5907, 160, 0);
        if (isActive("powder_inspection")) {
            effect(player, class_1294.field_5918, 160, 0);
            effect(player, class_1294.field_5907, 160, 0);
        }
    }

    private void onUseItem(class_3222 player, class_1268 hand) {
        class_1799 stack = player.method_5998(hand);
        if (isActive("siege_rations") && stack.method_19267()) {
            effect(player, class_1294.field_5910, 200, 0);
            player.method_7344().method_7585(-1, 0);
        }
        if (isActive("festival_law") && (stack.method_31574(class_1802.field_17534) || stack.method_31574(class_1802.field_8423) || stack.method_31574(class_1802.field_8741))) {
            effect(player, class_1294.field_5913, 240, 0);
        }
        if (isActive("fisher_auction") && stack.method_31574(class_1802.field_8378)) effect(player, class_1294.field_5926, 240, 0);
    }

    private void onUseBlock(class_3222 player, class_2248 block) {
        if (isActive("safe_lodging") && block instanceof net.minecraft.class_2244) {
            player.method_6016(class_1294.field_5899);
            player.method_6016(class_1294.field_5903);
        }
        if (isActive("market_day") && block == class_2246.field_16332) effect(player, class_1294.field_5924, 160, 0);
    }

    private void onTick(MinecraftServer server) {
        if (++tickCounter % 100 != 0) return;
        for (class_3222 player : server.method_3760().method_14571()) {
            boolean king = isKing(player);
            if (isActive("velvet_gaol")) effect(player, king ? class_1294.field_5907 : class_1294.field_5901, 140, king ? 1 : 0);
            if (isActive("royal_physician")) {
                if (king) effect(player, class_1294.field_5924, 140, 1);
                else if (player.method_6113()) player.method_18400();
            }
            if (isActive("private_armory") && !king) effect(player, class_1294.field_5911, 140, 0);
            if (isActive("silken_roads")) effect(player, king ? class_1294.field_5904 : class_1294.field_5909, 140, king ? 1 : 0);
            if (isActive("dragon_seal") && king) effect(player, class_1294.field_5918, 140, 0);
            if (isActive("ration_cards")) effect(player, class_1294.field_5903, 140, 0);
            if (isActive("night_school") && !player.method_37908().method_8530()) effect(player, class_1294.field_5925, 220, 0);
            if (isActive("blood_standard") || isActive("bread_and_circuses")) {
                player.method_5996(net.minecraft.class_5134.field_23716).method_6192(16.0);
            } else {
                player.method_5996(net.minecraft.class_5134.field_23716).method_6192(20.0);
            }
        }
        if (tickCounter % 1200 == 0) lowHealthCooldown.clear();
    }

    private boolean isKing(class_3222 player) {
        return player.method_5845().equals(officeService.getRuler());
    }

    private boolean isOre(class_2248 block) {
        String name = block.method_9518().getString();
        return name.contains("Ore");
    }

    private boolean isLog(class_2248 block) {
        String name = block.method_9518().getString();
        return name.contains("Log") || name.contains("Stem");
    }

    private boolean isCrop(class_2248 block) {
        return block == class_2246.field_10293 || block == class_2246.field_10609 || block == class_2246.field_10247 || block == class_2246.field_10341;
    }

    private void effect(class_3222 player, net.minecraft.class_1291 effect, int ticks, int amplifier) {
        player.method_6092(new class_1293(effect, ticks, amplifier, true, false, true));
    }

    private void xp(class_3222 player, int amount) {
        int adjusted = amount;
        if (isActive("crown_tax")) adjusted = isKing(player) ? Math.max(1, Math.round(amount * 1.4f)) : Math.max(0, Math.round(amount * 0.85f));
        if (isActive("austerity_act") && !isKing(player)) adjusted = Math.max(0, Math.round(adjusted * 0.9f));
        plugin.getTreasuryService().collectTax(player, "xp", adjusted);
        player.method_7255(adjusted);
    }

    private void drop(class_3222 player, String itemId, int count) {
        var item = class_7923.field_41178.method_10223(new class_2960(itemId));
        if (item == class_1802.field_8162) return;
        class_1542 entity = new class_1542(player.method_37908(), player.method_23317(), player.method_23318(), player.method_23321(), new class_1799(item, count));
        player.method_37908().method_8649(entity);
    }

    public record ApplyResult(boolean success, String message) {}
}
