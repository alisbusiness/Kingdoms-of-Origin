package com.example.kingdoms.treasury;

import net.minecraft.class_124;

public enum ReserveHealth {
    FULLY_BACKED("Fully Backed", 1.00, 3, -3, class_124.field_1060),
    STABLE("Stable", 0.75, 1, -1, class_124.field_1075),
    STRAINED("Strained", 0.50, -2, 4, class_124.field_1054),
    DEBASED("Debased", 0.25, -5, 9, class_124.field_1061),
    INSOLVENT("Insolvent", 0.00, -10, 16, class_124.field_1079);

    private final String label;
    private final double threshold;
    private final int legitimacyDelta;
    private final int unrestDelta;
    private final class_124 color;

    ReserveHealth(String label, double threshold, int legitimacyDelta, int unrestDelta, class_124 color) {
        this.label = label;
        this.threshold = threshold;
        this.legitimacyDelta = legitimacyDelta;
        this.unrestDelta = unrestDelta;
        this.color = color;
    }

    public static ReserveHealth fromRatio(double ratio) {
        if (ratio >= FULLY_BACKED.threshold) return FULLY_BACKED;
        if (ratio >= STABLE.threshold) return STABLE;
        if (ratio >= STRAINED.threshold) return STRAINED;
        if (ratio >= DEBASED.threshold) return DEBASED;
        return INSOLVENT;
    }

    public String label() { return label; }
    public int legitimacyDelta() { return legitimacyDelta; }
    public int unrestDelta() { return unrestDelta; }
    public class_124 color() { return color; }
}
