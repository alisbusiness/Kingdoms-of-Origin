package com.example.kingdoms.treasury;

import net.minecraft.class_124;

public enum StabilityBand {
    CALM("Calm", class_124.field_1060),
    UNEASY("Uneasy", class_124.field_1054),
    UNREST("Unrest", class_124.field_1065),
    CRISIS("Crisis", class_124.field_1061),
    REVOLT_WINDOW("Revolt Window", class_124.field_1079);

    private final String label;
    private final class_124 color;

    StabilityBand(String label, class_124 color) {
        this.label = label;
        this.color = color;
    }

    public static StabilityBand fromUnrest(int unrest) {
        if (unrest >= 80) return REVOLT_WINDOW;
        if (unrest >= 60) return CRISIS;
        if (unrest >= 40) return UNREST;
        if (unrest >= 20) return UNEASY;
        return CALM;
    }

    public String label() { return label; }
    public class_124 color() { return color; }
}
