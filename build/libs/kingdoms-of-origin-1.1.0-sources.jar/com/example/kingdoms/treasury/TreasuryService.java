package com.example.kingdoms.treasury;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.config.ConfigLoader;
import com.example.kingdoms.db.PersistenceService;
import com.example.kingdoms.election.ElectionException;
import com.example.kingdoms.origin.OfficeService;
import com.example.kingdoms.ui.AnnouncementService;
import net.minecraft.class_124;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.sql.SQLException;

public final class TreasuryService {
    public static final String CURRENCY_NAME = "Crowns";

    private final PersistenceService persistence;
    private final ConfigLoader config;
    private final OfficeService officeService;
    private AnnouncementService announcementService;
    private MinecraftServer server;
    private int auditTicks;

    public TreasuryService(PersistenceService persistence, ConfigLoader config, OfficeService officeService) {
        this.persistence = persistence;
        this.config = config;
        this.officeService = officeService;
    }

    public void setAnnouncementService(AnnouncementService announcementService) {
        this.announcementService = announcementService;
    }

    public void setServer(MinecraftServer server) {
        this.server = server;
    }

    public synchronized TreasuryState state() throws SQLException {
        return persistence.treasury().get(config.office().id());
    }

    public synchronized int balance(String playerUuid) throws SQLException {
        return persistence.treasury().balance(playerUuid);
    }

    public String currencyName() {
        return config.treasury().currencyName();
    }

    public synchronized void depositReserves(class_3222 actor, int diamonds, int blocks) throws SQLException {
        if (diamonds < 0 || blocks < 0) return;
        int removedDiamonds = removeItems(actor, class_1802.field_8477, diamonds);
        int removedBlocks = removeItems(actor, class_1802.field_8603, blocks);
        if (removedDiamonds == 0 && removedBlocks == 0) {
            actor.method_7353(class_2561.method_43470("No diamonds or diamond blocks were deposited.").method_27692(class_124.field_1061), false);
            return;
        }
        TreasuryState s = state();
        save(copy(s, s.rawDiamonds() + removedDiamonds, s.diamondBlocks() + removedBlocks, s.currencySupply(),
            s.taxesCollected(), s.publicSpending(), s.treasuryWithdrawals(), s.emergencyMinting(),
            s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(), s.emergencyLevyRate(),
            clamp(s.legitimacy() + 2), clampHeat(s.corruptionHeat() - 1), clamp(s.unrest() - 4),
            s.revoltActive(), s.revoltStartedAt(), s.captureProgress(), s.transitionFreezeUntil()));
        persistence.treasury().ledger(config.office().id(), actor.method_5845(), "reserve_deposit",
            removedDiamonds + removedBlocks * 9, true, "Diamond reserves deposited");
        actor.method_7353(class_2561.method_43470("Deposited " + removedDiamonds + " diamonds and " + removedBlocks + " diamond blocks.").method_27692(class_124.field_1060), false);
        auditAndMaybeRevolt("Reserve recovery");
    }

    public synchronized void setTax(class_3222 actor, String channel, int rate) throws SQLException {
        requireKing(actor);
        TreasuryState s = state();
        int cap = switch (channel) {
            case "xp" -> config.treasury().xpTaxCap();
            case "trade" -> config.treasury().tradeTaxCap();
            case "resource" -> config.treasury().resourceTaxCap();
            case "levy" -> config.treasury().levyTaxCap();
            default -> throw new IllegalArgumentException("Unknown tax channel: " + channel);
        };
        int next = Math.max(0, Math.min(cap, rate));
        int old = switch (channel) {
            case "xp" -> s.xpTaxRate();
            case "trade" -> s.tradeTaxRate();
            case "resource" -> s.resourceTitheRate();
            case "levy" -> s.emergencyLevyRate();
            default -> 0;
        };
        int hike = Math.max(0, next - old);
        save(copy(s, s.rawDiamonds(), s.diamondBlocks(), s.currencySupply(), s.taxesCollected(),
            s.publicSpending(), s.treasuryWithdrawals(), s.emergencyMinting(),
            channel.equals("xp") ? next : s.xpTaxRate(),
            channel.equals("trade") ? next : s.tradeTaxRate(),
            channel.equals("resource") ? next : s.resourceTitheRate(),
            channel.equals("levy") ? next : s.emergencyLevyRate(),
            clamp(s.legitimacy() - hike / 4), clampHeat(s.corruptionHeat() + (channel.equals("levy") ? hike / 3 : hike / 6)),
            clamp(s.unrest() + hike / 2 + (next > 20 ? 4 : 0)), s.revoltActive(), s.revoltStartedAt(), s.captureProgress(), s.transitionFreezeUntil()));
        persistence.treasury().ledger(config.office().id(), actor.method_5845(), "tax_policy", next, true, channel + " tax set to " + next + "%");
        broadcast(class_2561.method_43470("Tax policy changed: " + channel + " tax is now " + next + "%.").method_27692(next > 20 ? class_124.field_1061 : class_124.field_1065));
        auditAndMaybeRevolt("Tax hike");
    }

    public synchronized void mint(class_3222 actor, int amount, boolean emergency) throws SQLException {
        requireKing(actor);
        TreasuryState s = state();
        if (s.revoltActive()) throw new IllegalStateException("Minting is suspended during active revolt.");
        if (System.currentTimeMillis() < s.transitionFreezeUntil()) throw new IllegalStateException("Treasury controls are frozen during transition.");
        int minted = Math.max(1, Math.min(amount, config.treasury().mintMax()));
        int unsupported = Math.max(0, s.currencySupply() + minted - s.reserveValue());
        save(copy(s, s.rawDiamonds(), s.diamondBlocks(), s.currencySupply() + minted, s.taxesCollected(),
            s.publicSpending(), s.treasuryWithdrawals(), emergency ? s.emergencyMinting() + minted : s.emergencyMinting(),
            s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(), s.emergencyLevyRate(),
            clamp(s.legitimacy() - unsupported / 20 - (emergency ? 2 : 0)),
            clampHeat(s.corruptionHeat() + unsupported / 15 + (emergency ? 5 : 1)),
            clamp(s.unrest() + unsupported / 12 + (emergency ? 5 : 1)),
            s.revoltActive(), s.revoltStartedAt(), s.captureProgress(), s.transitionFreezeUntil()));
        persistence.treasury().adjustBalance(actor.method_5845(), minted);
        persistence.treasury().ledger(config.office().id(), actor.method_5845(), emergency ? "emergency_mint" : "mint", minted, true, "New Crowns issued");
        broadcast(class_2561.method_43470("The Crown minted " + minted + " " + currencyName() + ". Reserve backing is now " + ratioText(state()) + ".").method_27692(unsupported > 0 ? class_124.field_1061 : class_124.field_1065));
        auditAndMaybeRevolt("Currency issuance");
    }

    public synchronized void redeem(class_3222 actor, int amount) throws SQLException {
        int wanted = Math.max(1, amount);
        int bal = balance(actor.method_5845());
        if (bal < wanted) {
            actor.method_7353(class_2561.method_43470("You only hold " + bal + " " + currencyName() + ".").method_27692(class_124.field_1061), false);
            return;
        }
        TreasuryState s = state();
        int redeemable = Math.min(wanted, s.reserveValue());
        if (redeemable <= 0) {
            save(copy(s, s.rawDiamonds(), s.diamondBlocks(), s.currencySupply(), s.taxesCollected(), s.publicSpending(),
                s.treasuryWithdrawals(), s.emergencyMinting(), s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(),
                s.emergencyLevyRate(), clamp(s.legitimacy() - 12), clampHeat(s.corruptionHeat() + 8), clamp(s.unrest() + 18),
                s.revoltActive(), s.revoltStartedAt(), s.captureProgress(), s.transitionFreezeUntil()));
            broadcast(class_2561.method_43470("Redemption has failed: the treasury cannot pay diamonds for Crowns.").method_27692(class_124.field_1079));
            auditAndMaybeRevolt("Failed redemption");
            return;
        }
        int blocksToPay = Math.min(s.diamondBlocks(), redeemable / 9);
        int diamondsToPay = redeemable - blocksToPay * 9;
        if (diamondsToPay > s.rawDiamonds()) {
            int needed = diamondsToPay - s.rawDiamonds();
            int extraBlocks = Math.min(s.diamondBlocks() - blocksToPay, (needed + 8) / 9);
            blocksToPay += extraBlocks;
            diamondsToPay = Math.max(0, redeemable - blocksToPay * 9);
        }
        actor.method_7270(new net.minecraft.class_1799(class_1802.field_8603, blocksToPay));
        actor.method_7270(new net.minecraft.class_1799(class_1802.field_8477, diamondsToPay));
        persistence.treasury().adjustBalance(actor.method_5845(), -redeemable);
        save(copy(s, s.rawDiamonds() - diamondsToPay, s.diamondBlocks() - blocksToPay, Math.max(0, s.currencySupply() - redeemable),
            s.taxesCollected(), s.publicSpending(), s.treasuryWithdrawals(), s.emergencyMinting(), s.xpTaxRate(), s.tradeTaxRate(),
            s.resourceTitheRate(), s.emergencyLevyRate(), s.legitimacy(), s.corruptionHeat(), wanted > redeemable ? clamp(s.unrest() + 10) : s.unrest(),
            s.revoltActive(), s.revoltStartedAt(), s.captureProgress(), s.transitionFreezeUntil()));
        persistence.treasury().ledger(config.office().id(), actor.method_5845(), "redemption", redeemable, true, "Crowns redeemed for diamond reserves");
        if (wanted > redeemable) broadcast(class_2561.method_43470("Partial redemption: reserves ran short before all Crowns were honored.").method_27692(class_124.field_1061));
        auditAndMaybeRevolt("Redemption pressure");
    }

    public synchronized void spend(class_3222 actor, SpendingCategory category, int amount) throws SQLException {
        requireKing(actor);
        TreasuryState s = state();
        int cost = Math.max(1, Math.min(amount, config.treasury().spendMax()));
        if (s.currencySupply() < cost && category.publicSpending()) throw new IllegalStateException("Not enough issued Crowns for this spending.");
        int nextSupply = category.publicSpending() ? Math.max(0, s.currencySupply() - cost) : s.currencySupply();
        if (category == SpendingCategory.SIPHON || category == SpendingCategory.PALACE) persistence.treasury().adjustBalance(actor.method_5845(), cost);
        save(copy(s, s.rawDiamonds(), s.diamondBlocks(), nextSupply, s.taxesCollected(),
            s.publicSpending() + (category.publicSpending() ? cost : 0),
            s.treasuryWithdrawals() + (!category.publicSpending() ? cost : 0),
            s.emergencyMinting(), s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(), s.emergencyLevyRate(),
            clamp(s.legitimacy() + category.legitimacyDelta()), clampHeat(s.corruptionHeat() + category.heatDelta()),
            clamp(s.unrest() + category.unrestDelta()), s.revoltActive(), s.revoltStartedAt(), s.captureProgress(), s.transitionFreezeUntil()));
        persistence.treasury().ledger(config.office().id(), actor.method_5845(), "spend_" + category.name().toLowerCase(), cost, category.publicSpending(), category.label());
        broadcast(class_2561.method_43470(category.publicSpending() ? "Treasury funded " + category.label() + " for " + cost + " Crowns." : "Rumors spread of " + category.label() + " spending.").method_27692(category.publicSpending() ? class_124.field_1060 : class_124.field_1079));
        auditAndMaybeRevolt("Treasury spending");
    }

    public synchronized void collectTax(class_3222 subject, String channel, int taxableAmount) {
        if (taxableAmount <= 0 || subject.method_5845().equals(officeService.getRuler())) return;
        try {
            TreasuryState s = state();
            int rate = switch (channel) {
                case "xp" -> s.xpTaxRate();
                case "resource" -> s.resourceTitheRate();
                case "trade" -> s.tradeTaxRate();
                case "levy" -> s.emergencyLevyRate();
                default -> 0;
            };
            if (rate <= 0) return;
            int collected = Math.max(1, taxableAmount * rate / 100);
            int reserveDiamonds = channel.equals("resource") ? collected : 0;
            int crownTaxes = channel.equals("resource") ? 0 : collected;
            save(copy(s, s.rawDiamonds() + reserveDiamonds, s.diamondBlocks(), s.currencySupply() + crownTaxes,
                s.taxesCollected() + collected, s.publicSpending(), s.treasuryWithdrawals(), s.emergencyMinting(),
                s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(), s.emergencyLevyRate(), s.legitimacy(),
                s.corruptionHeat(), clamp(s.unrest() + (rate > 20 ? 1 : 0)), s.revoltActive(), s.revoltStartedAt(),
                s.captureProgress(), s.transitionFreezeUntil()));
            persistence.treasury().ledger(config.office().id(), subject.method_5845(), channel + "_tax", collected, true, "Collected by tax policy");
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Failed to collect {} tax from {}", channel, subject.method_5845(), e);
        }
    }

    public synchronized void joinRevolt(class_3222 player, String side) throws SQLException {
        TreasuryState s = state();
        if (!s.revoltActive()) {
            player.method_7353(class_2561.method_43470("There is no active revolt window.").method_27692(class_124.field_1061), false);
            return;
        }
        String normalized = side.equalsIgnoreCase("loyalist") || side.equalsIgnoreCase("crown") ? "LOYALIST" : "REBEL";
        persistence.treasury().joinSide(player.method_5845(), normalized);
        broadcast(class_2561.method_43470(player.method_5477().getString() + " declared for the " + (normalized.equals("REBEL") ? "revolt." : "crown.")).method_27692(normalized.equals("REBEL") ? class_124.field_1061 : class_124.field_1065));
    }

    public synchronized void onServerMinute(MinecraftServer server) {
        this.server = server;
        try {
            if (++auditTicks % 5 == 0) auditAndMaybeRevolt("Periodic audit");
            tickCapture(server);
        } catch (Exception e) {
            KingdomsPlugin.LOGGER.error("Treasury tick failed", e);
        }
    }

    public synchronized void freezeTransition() throws SQLException {
        TreasuryState s = state();
        save(copy(s, s.rawDiamonds(), s.diamondBlocks(), s.currencySupply(), s.taxesCollected(), s.publicSpending(),
            s.treasuryWithdrawals(), s.emergencyMinting(), s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(),
            s.emergencyLevyRate(), clamp(s.legitimacy() + 5), clampHeat(s.corruptionHeat() - 15), clamp(Math.min(s.unrest(), 45)),
            false, 0L, 0, System.currentTimeMillis() + (long) config.treasury().transitionFreezeMinutes() * 60L * 1000L));
        persistence.treasury().clearParticipants();
    }

    private void tickCapture(MinecraftServer server) throws SQLException, ElectionException {
        TreasuryState s = state();
        if (!s.revoltActive()) return;
        int rebelsJoined = persistence.treasury().sideCount("REBEL");
        int rebels = 0;
        int loyalists = 0;
        for (class_3222 p : server.method_3760().method_14571()) {
            double radius = config.revolt().captureRadius();
            if (p.method_5649(config.revolt().capitalX(), config.revolt().capitalY(), config.revolt().capitalZ()) > radius * radius) continue;
            String side = persistence.treasury().side(p.method_5845());
            if ("REBEL".equals(side)) rebels++;
            if ("LOYALIST".equals(side) || p.method_5845().equals(officeService.getRuler())) loyalists++;
        }
        int progress = s.captureProgress();
        if (rebelsJoined >= minimumRebels(server) && rebels > loyalists && rebels > 0) progress = Math.min(config.revolt().captureRequired(), progress + 8);
        else if (loyalists >= rebels && progress > 0) progress = Math.max(0, progress - 5);
        if (progress != s.captureProgress()) {
            save(copy(s, s.rawDiamonds(), s.diamondBlocks(), s.currencySupply(), s.taxesCollected(), s.publicSpending(),
                s.treasuryWithdrawals(), s.emergencyMinting(), s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(), s.emergencyLevyRate(),
                s.legitimacy(), s.corruptionHeat(), s.unrest(), true, s.revoltStartedAt(), progress, s.transitionFreezeUntil()));
            broadcast(class_2561.method_43470("Capital capture: " + progress + "% (" + rebels + " rebels, " + loyalists + " loyalists at the capital).").method_27692(class_124.field_1061));
        }
        if (progress >= config.revolt().captureRequired()) {
            String old = officeService.getRuler();
            officeService.removeRuler(OfficeService.RemovalReason.FORCED);
            freezeTransition();
            broadcast(class_2561.method_43470("The capital has fallen. The King has been overthrown by popular revolt.").method_27692(class_124.field_1079));
            persistence.history().insert(new com.example.kingdoms.db.model.History(0, "revolt_success", old, null, "{\"capital\":\"" + capitalText() + "\"}", System.currentTimeMillis()));
            if (config.office().electionEnabled()) KingdomsPlugin.getInstance().startElectionAndSchedule(config.office().id());
        }
    }

    private void auditAndMaybeRevolt(String reason) throws SQLException {
        TreasuryState s = state();
        ReserveHealth health = s.reserveHealth();
        int legitimacy = clamp(s.legitimacy() + health.legitimacyDelta() / 2 - s.corruptionHeat() / 35);
        int unrest = clamp(s.unrest() + health.unrestDelta() / 2 + (s.legitimacy() < 35 ? 3 : 0) + (s.corruptionHeat() > 70 ? 4 : 0));
        boolean opens = !s.revoltActive() && unrest >= config.revolt().threshold();
        save(copy(s, s.rawDiamonds(), s.diamondBlocks(), s.currencySupply(), s.taxesCollected(), s.publicSpending(),
            s.treasuryWithdrawals(), s.emergencyMinting(), s.xpTaxRate(), s.tradeTaxRate(), s.resourceTitheRate(), s.emergencyLevyRate(),
            legitimacy, s.corruptionHeat(), unrest, s.revoltActive() || opens, opens ? System.currentTimeMillis() : s.revoltStartedAt(),
            s.captureProgress(), s.transitionFreezeUntil()));
        if (opens) {
            broadcast(class_2561.method_43470("REVOLT WINDOW OPEN: unrest has reached " + unrest + "/100. Seize the capital at " + capitalText() + " to overthrow the King.").method_27692(class_124.field_1079));
            if (announcementService != null) announcementService.showRevoltBossBar(class_2561.method_43470("Revolt Window - Capture the Capital").method_27692(class_124.field_1079));
        } else if (health == ReserveHealth.DEBASED || health == ReserveHealth.INSOLVENT) {
            broadcast(class_2561.method_43470("Treasury audit: " + health.label() + ". " + reason + " has shaken confidence.").method_27692(health.color()));
        }
    }

    private int minimumRebels(MinecraftServer server) {
        int online = server.method_3760().method_14571().size();
        return Math.max(1, Math.min(3, (online + 1) / 2));
    }

    public String capitalText() {
        return Math.round(config.revolt().capitalX()) + " " + Math.round(config.revolt().capitalY()) + " " + Math.round(config.revolt().capitalZ());
    }

    private void requireKing(class_3222 actor) {
        if (!actor.method_5845().equals(officeService.getRuler())) throw new IllegalStateException("Only the King may use this power.");
    }

    private void broadcast(class_2561 text) {
        if (server != null) server.method_3760().method_43514(text, false);
    }

    private void save(TreasuryState state) throws SQLException {
        persistence.treasury().save(state);
    }

    private int removeItems(class_3222 player, net.minecraft.class_1792 item, int count) {
        int left = count;
        for (int i = 0; i < player.method_31548().method_5439() && left > 0; i++) {
            var stack = player.method_31548().method_5438(i);
            if (!stack.method_31574(item)) continue;
            int take = Math.min(left, stack.method_7947());
            stack.method_7934(take);
            left -= take;
        }
        return count - left;
    }

    private static String ratioText(TreasuryState s) {
        return Math.round(s.reserveRatio() * 100.0) + "%";
    }

    private static int clamp(int v) { return Math.max(0, Math.min(100, v)); }
    private static int clampHeat(int v) { return Math.max(0, Math.min(100, v)); }

    private static TreasuryState copy(TreasuryState s, int raw, int blocks, int supply, int taxes, int publicSpend,
                                      int withdrawals, int emergencyMint, int xp, int trade, int resource, int levy,
                                      int legitimacy, int heat, int unrest, boolean revolt, long revoltAt,
                                      int capture, long freezeUntil) {
        return new TreasuryState(s.officeId(), raw, blocks, supply, taxes, publicSpend, withdrawals, emergencyMint,
            xp, trade, resource, levy, legitimacy, heat, unrest, revolt, revoltAt, capture, freezeUntil, System.currentTimeMillis());
    }
}
