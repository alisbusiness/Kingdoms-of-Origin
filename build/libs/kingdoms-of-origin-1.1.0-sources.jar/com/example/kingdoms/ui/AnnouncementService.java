package com.example.kingdoms.ui;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.config.ConfigLoader;
import net.minecraft.class_1259;
import net.minecraft.class_2561;
import net.minecraft.class_3213;
import net.minecraft.server.MinecraftServer;
import java.util.List;

/**
 * Sends server-wide election and ruler announcements via chat and optional boss bar.
 * Which channels are used is controlled by the ui section in config.yml.
 */
public final class AnnouncementService {

    private final ConfigLoader config;
    private MinecraftServer server;

    private class_3213 electionBossBar;
    private class_3213 revoltBossBar;

    public AnnouncementService(ConfigLoader config) {
        this.config = config;
    }

    public void setServer(MinecraftServer server) {
        this.server = server;
    }

    // ------------------------------------------------------------------
    // Public broadcast methods
    // ------------------------------------------------------------------

    public void broadcastElectionStart(String officeName) {
        class_2561 msg = Messages.announceElectionStart(officeName);
        broadcastChat(msg);

        if (config.ui().useBossbarDuringElection()) {
            showElectionBossBar(class_2561.method_43470("Election in Progress — Nominations Open")
                .method_27692(net.minecraft.class_124.field_1065));
        }
    }

    public void broadcastVotingOpen(List<String> candidateNames) {
        broadcastChat(Messages.announceVotingOpen(candidateNames));

        if (electionBossBar != null) {
            electionBossBar.method_5413(class_2561.method_43470("Election — VOTING OPEN")
                .method_27692(net.minecraft.class_124.field_1060));
            electionBossBar.method_5416(class_1259.class_1260.field_5785);
        }
    }

    public void broadcastWinner(String winnerName) {
        broadcastChat(Messages.announceWinner(winnerName));
        dismissElectionBossBar();
    }

    public void broadcastRulerChange(String oldRuler, String newRuler) {
        broadcastChat(Messages.announceRulerChange(oldRuler, newRuler));
    }

    public void broadcastSpeech(String rulerName, String message) {
        broadcastChat(Messages.announceRoyalDecree(rulerName, message));
    }

    // ------------------------------------------------------------------
    // Boss bar lifecycle
    // ------------------------------------------------------------------

    private void showElectionBossBar(class_2561 title) {
        if (server == null) return;
        dismissElectionBossBar();
        electionBossBar = new class_3213(title, class_1259.class_1260.field_5782, class_1259.class_1261.field_5795);
        server.method_3760().method_14571().forEach(electionBossBar::method_14088);
    }

    public void addPlayerToBossBar(net.minecraft.class_3222 player) {
        if (electionBossBar != null) electionBossBar.method_14088(player);
        if (revoltBossBar != null) revoltBossBar.method_14088(player);
    }

    public void dismissElectionBossBar() {
        if (electionBossBar != null) {
            electionBossBar.method_14094();
            electionBossBar = null;
        }
    }

    public void showRevoltBossBar(class_2561 title) {
        if (server == null) return;
        dismissRevoltBossBar();
        revoltBossBar = new class_3213(title, class_1259.class_1260.field_5784, class_1259.class_1261.field_5795);
        revoltBossBar.method_5408(1.0f);
        server.method_3760().method_14571().forEach(revoltBossBar::method_14088);
    }

    public void dismissRevoltBossBar() {
        if (revoltBossBar != null) {
            revoltBossBar.method_14094();
            revoltBossBar = null;
        }
    }

    // ------------------------------------------------------------------
    // Internals
    // ------------------------------------------------------------------

    private void broadcastChat(class_2561 message) {
        if (!config.ui().sendChatBroadcasts()) return;
        if (server == null) {
            KingdomsPlugin.LOGGER.warn("AnnouncementService.broadcastChat called before server was set");
            return;
        }
        server.method_3760().method_43514(message, false);
    }
}
