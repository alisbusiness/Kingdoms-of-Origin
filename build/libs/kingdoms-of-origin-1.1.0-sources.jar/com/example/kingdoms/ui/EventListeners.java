package com.example.kingdoms.ui;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.election.ElectionException;
import com.example.kingdoms.origin.OfficeService;
import com.example.kingdoms.origin.PlayerStateService;
import com.example.kingdoms.perk.PerkRegistry;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.message.v1.ServerMessageEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.SQLException;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registers Fabric event callbacks for player join, server tick, chat interception,
 * and a death hook stub.
 */
public final class EventListeners {

    private static final Logger LOGGER = LoggerFactory.getLogger(EventListeners.class);

    private final KingdomsPlugin plugin;
    private final OfficeService officeService;
    private final AnnouncementService announcementService;
    private final PlayerStateService playerStateService;

    private final Set<UUID> pendingSpeech =
        ConcurrentHashMap.newKeySet();
    private final Set<UUID> pendingLawRewrite =
        ConcurrentHashMap.newKeySet();

    private int tickCounter = 0;
    private static final int TICKS_PER_MINUTE = 20 * 60;
    private static final int MAX_SPEECH_LENGTH = 256;

    public EventListeners(
        KingdomsPlugin plugin,
        OfficeService officeService,
        AnnouncementService announcementService,
        PlayerStateService playerStateService
    ) {
        this.plugin              = plugin;
        this.officeService       = officeService;
        this.announcementService = announcementService;
        this.playerStateService  = playerStateService;
    }

    // ------------------------------------------------------------------
    // Registration
    // ------------------------------------------------------------------

    public void register() {
        registerJoinListener();
        registerTickListener();
        registerChatListener();
        registerDeathHookStub();
    }

    // ------------------------------------------------------------------
    // Speech prompt API (called by GuiService)
    // ------------------------------------------------------------------

    public void setPendingSpeech(UUID playerUuid) {
        pendingSpeech.add(playerUuid);
    }

    public void clearPendingSpeech(UUID playerUuid) {
        pendingSpeech.remove(playerUuid);
    }

    public void setPendingLawRewrite(UUID playerUuid) {
        pendingLawRewrite.add(playerUuid);
    }

    public void clearPendingLawRewrite(UUID playerUuid) {
        pendingLawRewrite.remove(playerUuid);
    }

    // ------------------------------------------------------------------
    // Join listener (consolidated — replaces duplicate in PlayerStateService)
    // ------------------------------------------------------------------

    private void registerJoinListener() {
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();

            // 1. First-join random origin assignment and player record upsert
            playerStateService.handleJoin(player);

            // 2. Give the boss bar to the newly joined player if an election is running
            announcementService.addPlayerToBossBar(player);

            // 3. Validate king origin sync for the ruler on login
            String rulerUuid = officeService.getRuler();
            if (rulerUuid != null && rulerUuid.equals(player.method_5845())) {
                server.execute(() -> plugin.getTransferService().validateSync(player));
            }

            // 3.5 Interim King logic: if no ruler and this is the first player ever to join
            if (rulerUuid == null) {
                try {
                    if (plugin.getPersistence().players().findAll().size() <= 1) {
                        officeService.assignRuler(player.method_5667());
                        player.method_7353(net.minecraft.class_2561.method_43470("You are the interim King! Run /kingdom start-election to begin elections.").method_27692(net.minecraft.class_124.field_1065), false);
                        // Re-validate after assignment so the King origin is actually applied,
                        // even if Origins' first-join flow tries to overwrite it.
                        server.execute(() -> plugin.getTransferService().validateSync(player));
                    }
                } catch (SQLException e) {
                    LOGGER.error("Failed to assign interim king", e);
                }
            }

            // 4. Clean up all old perks
            for (String perk : PerkRegistry.legacyOriginPowerIds()) {
                server.method_3734().method_44252(server.method_3739(), 
                    "power revoke " + player.method_5477().getString() + " kingdoms_of_origin:perks/" + perk);
            }

            // 5. New policy perks are enforced server-side by PerkService.
            plugin.getPerkService().reloadActive();
        });
    }

    // ------------------------------------------------------------------
    // Tick listener — term expiration
    // ------------------------------------------------------------------

    private void registerTickListener() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++tickCounter < TICKS_PER_MINUTE) return;
            tickCounter = 0;
            checkTermExpiration(server);
            plugin.getTreasuryService().onServerMinute(server);
        });
    }

    private void checkTermExpiration(MinecraftServer server) {
        long   now       = System.currentTimeMillis();
        long   termEnd   = officeService.getTermEnd();
        String rulerUuid = officeService.getRuler();

        if (rulerUuid == null || termEnd == 0) return;
        if (now < termEnd) return;

        LOGGER.info("Term expired for ruler {}; removing from office.", rulerUuid);
        try {
            String rulerName = resolvePlayerName(server, rulerUuid);
            officeService.removeRuler(OfficeService.RemovalReason.TERM_END);
            announcementService.broadcastRulerChange(rulerName, null);

            // Start a new election if elections are enabled
            if (plugin.getConfig().office().electionEnabled()) {
                plugin.startElectionAndSchedule(plugin.getConfig().office().id());
            }
        } catch (ElectionException e) {
            LOGGER.error("Failed to start new election after term expiration: {}", e.getMessage(), e);
        } catch (SQLException e) {
            LOGGER.error("Failed to handle term expiration for ruler {}", rulerUuid, e);
        }
    }

    // ------------------------------------------------------------------
    // Chat listener — royal speech interception
    // ------------------------------------------------------------------

    private void registerChatListener() {
        ServerMessageEvents.ALLOW_CHAT_MESSAGE.register((message, sender, params) -> {
            UUID senderUuid = sender.method_5667();
            if (!pendingLawRewrite.remove(senderUuid)) return true;

            String text = message.method_46291().getString();
            if ("cancel".equalsIgnoreCase(text.trim())) {
                sender.method_7353(net.minecraft.class_2561.method_43470("Royal law rewrite cancelled.").method_27692(net.minecraft.class_124.field_1080), false);
                return false;
            }

            try {
                plugin.getLawService().replaceFromBook(sender, text);
                sender.method_7353(net.minecraft.class_2561.method_43470("Royal law book updated.").method_27692(net.minecraft.class_124.field_1060), false);
            } catch (Exception e) {
                sender.method_7353(net.minecraft.class_2561.method_43470(e.getMessage()).method_27692(net.minecraft.class_124.field_1061), false);
            }
            return false;
        });

        ServerMessageEvents.CHAT_MESSAGE.register((message, sender, params) -> {
            UUID senderUuid = sender.method_5667();
            if (!pendingSpeech.remove(senderUuid)) return;

            String rulerName = sender.method_5477().getString();
            String text      = sanitizeSpeech(message.method_46291().getString());
            announcementService.broadcastSpeech(rulerName, text);
        });
    }

    // ------------------------------------------------------------------
    // Death hook stub
    // ------------------------------------------------------------------

    private void registerDeathHookStub() {
        ServerLivingEntityEvents.ALLOW_DEATH.register((entity, source, amount) -> {
            if (entity instanceof class_3222 player) {
                if (plugin.getConfig().debug().logGuiActions()) {
                    LOGGER.debug("Player {} died (source: {})", player.method_5845(), source.method_5525());
                }
            }
            return true;
        });
    }

    // ------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------

    private String resolvePlayerName(MinecraftServer server, String uuid) {
        try {
            class_3222 online = server.method_3760().method_14602(UUID.fromString(uuid));
            if (online != null) return online.method_5477().getString();
            return plugin.getPersistence().players().findByUuid(uuid)
                .map(p -> p.getUsername() != null ? p.getUsername() : uuid)
                .orElse(uuid);
        } catch (Exception e) {
            return uuid;
        }
    }

    private static String sanitizeSpeech(String text) {
        if (text == null || text.isBlank()) return "";
        String cleaned = text.replaceAll("\\p{Cntrl}", " ").replaceAll("\\s+", " ").trim();
        return cleaned.length() <= MAX_SPEECH_LENGTH
            ? cleaned
            : cleaned.substring(0, MAX_SPEECH_LENGTH).trim();
    }
}
