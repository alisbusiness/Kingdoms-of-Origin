package com.example.kingdoms.ui.command;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.db.model.Candidate;
import com.example.kingdoms.db.model.Election;
import com.example.kingdoms.db.model.OfficeState;
import com.example.kingdoms.election.ElectionException;
import com.example.kingdoms.election.ElectionPhase;
import com.example.kingdoms.election.ElectionService;
import com.example.kingdoms.item.RoyalLawBookItem;
import com.example.kingdoms.origin.OfficeService;
import com.example.kingdoms.origin.OriginAdapter;
import com.example.kingdoms.origin.OriginTransferService;
import com.example.kingdoms.perk.PerkDefinition;
import com.example.kingdoms.perk.PerkRegistry;
import com.example.kingdoms.perk.PerkRegistry.BudgetResult;
import com.example.kingdoms.perk.PerkService.ApplyResult;
import com.example.kingdoms.treasury.SpendingCategory;
import com.example.kingdoms.treasury.TreasuryState;
import com.example.kingdoms.treasury.TreasuryService;
import com.example.kingdoms.ui.Messages;
import com.example.kingdoms.ui.Permissions;
import com.example.kingdoms.ui.gui.GuiService;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.class_124;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1493;
import net.minecraft.class_1799;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2186;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.server.MinecraftServer;
import java.sql.SQLException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Registers all /kingdom commands using Fabric's Brigadier API.
 * Call {@link #register()} during ModInitializer.onInitialize() — before the server starts.
 */
public final class KingdomCommand {
    private static final int ROYAL_GUARD_COUNT = 5;
    private static final int ROYAL_GUARD_LIFETIME_TICKS = 20 * 10;
    private static final long ROYAL_GUARD_COOLDOWN_MILLIS = 10 * 60 * 1000L;

    private final KingdomsPlugin plugin;
    private final ElectionService electionService;
    private final OfficeService officeService;
    private final OriginTransferService transferService;
    private final GuiService guiService;
    private final Map<UUID, Long> royalGuardCooldowns = new ConcurrentHashMap<>();
    private final Map<UUID, Long> activeRoyalGuards = new ConcurrentHashMap<>();

    public KingdomCommand(
        KingdomsPlugin plugin,
        ElectionService electionService,
        OfficeService officeService,
        OriginTransferService transferService,
        GuiService guiService
    ) {
        this.plugin          = plugin;
        this.electionService = electionService;
        this.officeService   = officeService;
        this.transferService = transferService;
        this.guiService      = guiService;
    }

    public void register() {
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) ->
            build(dispatcher));
        ServerTickEvents.END_SERVER_TICK.register(this::tickRoyalGuards);
    }

    // ------------------------------------------------------------------
    // Command tree
    // ------------------------------------------------------------------

    private void build(CommandDispatcher<class_2168> dispatcher) {

        var kingdom = class_2170.method_9247("kingdom");

        // --- Player sub-commands ---

        kingdom.then(class_2170.method_9247("status")
            .requires(Permissions::isPlayer)
            .executes(this::cmdStatus));

        kingdom.then(class_2170.method_9247("origin")
            .requires(Permissions::isPlayer)
            .executes(this::cmdOrigin));

        kingdom.then(class_2170.method_9247("vote")
            .requires(Permissions::isPlayer)
            .executes(this::cmdVote));

        kingdom.then(class_2170.method_9247("candidates")
            .requires(Permissions::isPlayer)
            .executes(this::cmdCandidates));

        kingdom.then(class_2170.method_9247("run")
            .requires(Permissions::isPlayer)
            .then(class_2170.method_9244("slogan", StringArgumentType.greedyString())
                .executes(ctx -> cmdRun(ctx, StringArgumentType.getString(ctx, "slogan"))))
            .executes(ctx -> cmdRun(ctx, "")));

        kingdom.then(class_2170.method_9247("ruler")
            .requires(Permissions::isPlayer)
            .executes(this::cmdRuler));

        kingdom.then(class_2170.method_9247("promise")
            .requires(Permissions::isPlayer)
            .executes(this::cmdPromiseMenu)
            .then(class_2170.method_9244("perks", StringArgumentType.greedyString())
                .executes(ctx -> cmdPromise(ctx, StringArgumentType.getString(ctx, "perks")))));

        kingdom.then(class_2170.method_9247("setperks")
            .requires(Permissions::isPlayer)
            .executes(this::cmdSetPerksMenu)
            .then(class_2170.method_9244("perks", StringArgumentType.greedyString())
                .executes(ctx -> cmdSetPerks(ctx, StringArgumentType.getString(ctx, "perks")))));

        kingdom.then(class_2170.method_9247("perks")
            .requires(Permissions::isPlayer)
            .executes(this::cmdViewPerks));

        kingdom.then(class_2170.method_9247("perk")
            .then(class_2170.method_9244("id", StringArgumentType.word())
                .executes(ctx -> cmdInspectPerk(ctx, StringArgumentType.getString(ctx, "id")))));

        kingdom.then(class_2170.method_9247("trust")
            .executes(this::cmdTrust));

        kingdom.then(class_2170.method_9247("laws")
            .requires(Permissions::isPlayer)
            .executes(this::cmdLawsView)
            .then(class_2170.method_9247("view")
                .executes(this::cmdLawsView))
            .then(class_2170.method_9247("book")
                .executes(this::cmdLawsBook))
            .then(class_2170.method_9247("add")
                .then(class_2170.method_9244("text", StringArgumentType.greedyString())
                    .executes(ctx -> cmdLawAdd(ctx, StringArgumentType.getString(ctx, "text")))))
            .then(class_2170.method_9247("remove")
                .then(class_2170.method_9244("number", IntegerArgumentType.integer(1))
                    .executes(ctx -> cmdLawRemove(ctx, IntegerArgumentType.getInteger(ctx, "number"))))));

        kingdom.then(class_2170.method_9247("treasury")
            .requires(Permissions::isPlayer)
            .executes(this::cmdTreasury)
            .then(class_2170.method_9247("gui").executes(ctx -> withPlayer(ctx, guiService::openTreasuryMenu)))
            .then(class_2170.method_9247("deposit")
                .then(class_2170.method_9244("diamonds", IntegerArgumentType.integer(0))
                    .then(class_2170.method_9244("blocks", IntegerArgumentType.integer(0))
                        .executes(ctx -> cmdTreasuryDeposit(ctx, IntegerArgumentType.getInteger(ctx, "diamonds"), IntegerArgumentType.getInteger(ctx, "blocks"))))))
            .then(class_2170.method_9247("redeem")
                .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1))
                    .executes(ctx -> cmdRedeem(ctx, IntegerArgumentType.getInteger(ctx, "amount")))))
            .then(class_2170.method_9247("tax")
                .then(class_2170.method_9244("channel", StringArgumentType.word())
                    .then(class_2170.method_9244("rate", IntegerArgumentType.integer(0, 50))
                        .executes(ctx -> cmdSetTax(ctx, StringArgumentType.getString(ctx, "channel"), IntegerArgumentType.getInteger(ctx, "rate"))))))
            .then(class_2170.method_9247("mint")
                .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1, 500))
                    .executes(ctx -> cmdMint(ctx, IntegerArgumentType.getInteger(ctx, "amount"), false))))
            .then(class_2170.method_9247("emergency-mint")
                .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1, 500))
                    .executes(ctx -> cmdMint(ctx, IntegerArgumentType.getInteger(ctx, "amount"), true))))
            .then(class_2170.method_9247("spend")
                .then(class_2170.method_9244("category", StringArgumentType.word())
                    .then(class_2170.method_9244("amount", IntegerArgumentType.integer(1, 250))
                        .executes(ctx -> cmdSpend(ctx, StringArgumentType.getString(ctx, "category"), IntegerArgumentType.getInteger(ctx, "amount")))))));

        kingdom.then(class_2170.method_9247("revolt")
            .requires(Permissions::isPlayer)
            .executes(this::cmdRevolt)
            .then(class_2170.method_9247("join").executes(ctx -> cmdJoinRevolt(ctx, "rebel")))
            .then(class_2170.method_9247("defend").executes(ctx -> cmdJoinRevolt(ctx, "loyalist"))));

        kingdom.then(class_2170.method_9247("help")
            .executes(this::cmdHelp));

        kingdom.then(class_2170.method_9247("menu")
            .requires(Permissions::isPlayer)
            .executes(this::cmdMenu));

        kingdom.then(class_2170.method_9247("start-election")
            .requires(Permissions::isPlayer)
            .executes(this::cmdStartElection));

        kingdom.then(class_2170.method_9247("summon-guard")
            .requires(Permissions::isPlayer)
            .executes(this::cmdSummonGuard));

        // --- Admin sub-commands ---

        var admin = class_2170.method_9247("admin")
            .requires(Permissions::isAdmin);

        admin.then(class_2170.method_9247("start-election")
            .executes(this::adminStartElection));

        admin.then(class_2170.method_9247("end-election")
            .executes(this::adminEndElection));

        admin.then(class_2170.method_9247("set-ruler")
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(ctx -> adminSetRuler(ctx, class_2186.method_9315(ctx, "player")))));

        admin.then(class_2170.method_9247("remove-ruler")
            .executes(this::adminRemoveRuler));

        admin.then(class_2170.method_9247("force-transfer")
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(ctx -> adminForceTransfer(ctx, class_2186.method_9315(ctx, "player")))));

        admin.then(class_2170.method_9247("give-orb")
            .then(class_2170.method_9244("player", class_2186.method_9305())
                .executes(ctx -> adminGiveOrb(ctx, class_2186.method_9315(ctx, "player")))));

        admin.then(class_2170.method_9247("set-phase")
            .then(class_2170.method_9244("phase", StringArgumentType.word())
                .executes(ctx -> adminSetPhase(ctx, StringArgumentType.getString(ctx, "phase")))));

        admin.then(class_2170.method_9247("reload")
            .executes(this::adminReload));

        admin.then(class_2170.method_9247("debug-sync")
            .executes(this::adminDebugSync));

        admin.then(class_2170.method_9247("db-status")
            .executes(this::adminDbStatus));

        admin.then(class_2170.method_9247("election-status")
            .executes(this::adminElectionStatus));

        admin.then(class_2170.method_9247("treasury-ledger")
            .executes(this::adminTreasuryLedger));

        admin.then(class_2170.method_9247("repair-office-state")
            .executes(this::adminRepairOfficeState));

        kingdom.then(admin);

        dispatcher.register(kingdom);
    }

    // ------------------------------------------------------------------
    // Player command handlers
    // ------------------------------------------------------------------

    private int cmdStatus(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        String phase     = officeService.getPhase();
        long   termEnd   = officeService.getTermEnd();

        src.method_45068(Messages.statusHeader());
        if (rulerUuid != null) {
            src.method_45068(Messages.rulerLine(resolveOrUuid(src, rulerUuid)));
            src.method_45068(Messages.termEndLine(termEnd));
        } else {
            src.method_45068(Messages.noRuler());
        }
        src.method_45068(Messages.phaseLine(phase));
        return 1;
    }

    private int cmdOrigin(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            var adapter = plugin.getOriginAdapter();
            if (adapter == null) {
                player.method_7353(class_2561.method_43470("Origins integration is not active on this server.").method_27692(class_124.field_1054), false);
                return;
            }

            String primary = adapter.getCurrentOrigin(player);
            player.method_7353(class_2561.method_43470("Your Origin").method_27695(class_124.field_1065, class_124.field_1067), false);
            player.method_7353(class_2561.method_43470("Primary: " + displayOrigin(primary)).method_27692(class_124.field_1080), false);
            if (player.method_5845().equals(officeService.getRuler())) {
                player.method_7353(class_2561.method_43470("Office: " + plugin.getConfig().originMode().kingOriginId()).method_27692(class_124.field_1075), false);
            }
        });
    }

    private int cmdVote(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            ElectionPhase phase = ElectionPhase.fromString(officeService.getPhase());
            if (phase != ElectionPhase.VOTING) {
                player.method_7353(Messages.votingNotOpen(), false);
                return;
            }
            guiService.openCandidateList(player);
        });
    }

    private int cmdCandidates(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                try {
                    var candidates = electionService.getCandidates(election.getId());
                    src.method_45068(Messages.candidatesHeader(candidates.size()));
                    for (int i = 0; i < candidates.size(); i++) {
                        var c    = candidates.get(i);
                        String name = resolveOrUuid(src, c.getPlayerUuid());
                        src.method_45068(Messages.candidateLine(i, name, c.getSlogan()));
                    }
                    if (candidates.isEmpty()) src.method_45068(Messages.noCandidates());
                } catch (SQLException e) {
                    src.method_45068(Messages.error("Could not load candidates."));
                }
            }, () -> src.method_45068(Messages.noActiveElection()));
        } catch (SQLException e) {
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int cmdRun(CommandContext<class_2168> ctx, String slogan) {
        return withPlayer(ctx, player -> {
            try {
                String officeId = plugin.getConfig().office().id();
                electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                    try {
                        var candidate = electionService.registerCandidate(election.getId(), player.method_5845(), slogan);
                        player.method_7353(Messages.registeredAsCandidate(candidate.getSlogan()), false);
                    } catch (ElectionException e) {
                        String msg = e.getMessage();
                        if (msg.contains("already a candidate")) {
                            player.method_7353(Messages.alreadyCandidate(), false);
                        } else if (msg.contains("Nominations are closed")) {
                            player.method_7353(Messages.nominationsNotOpen(), false);
                        } else if (msg.contains("cannot run")) {
                            player.method_7353(Messages.holderCannotRun(), false);
                        } else {
                            player.method_7353(Messages.error(msg), false);
                        }
                    } catch (SQLException e) {
                        KingdomsPlugin.LOGGER.error("Register candidate failed", e);
                        player.method_7353(Messages.error("A server error occurred."), false);
                    }
                }, () -> player.method_7353(Messages.noActiveElection(), false));
            } catch (SQLException e) {
                KingdomsPlugin.LOGGER.error("Election lookup failed", e);
                player.method_7353(Messages.error("A server error occurred."), false);
            }
        });
    }

    private int cmdRuler(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        if (rulerUuid == null) {
            src.method_45068(Messages.noRuler());
        } else {
            src.method_45068(Messages.rulerLine(resolveOrUuid(src, rulerUuid)));
            src.method_45068(Messages.termEndLine(officeService.getTermEnd()));
            src.method_45068(Messages.phaseLine(officeService.getPhase()));
            String activePerks = officeService.getActivePerks();
            if (activePerks != null && !activePerks.isBlank()) {
                src.method_45068(net.minecraft.class_2561.method_43470("Active Policies: " + activePerks).method_27692(net.minecraft.class_124.field_1075));
            }
            try {
                src.method_45068(net.minecraft.class_2561.method_43470("Trust Score: " + plugin.getPersistence().trust().getScore(rulerUuid)).method_27692(net.minecraft.class_124.field_1060));
            } catch (SQLException ignored) {}
        }
        return 1;
    }

    private int cmdPromiseMenu(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> guiService.openPerkSelectionMenu(player, false, 0));
    }

    private int cmdPromise(CommandContext<class_2168> ctx, String perks) {
        return withPlayer(ctx, player -> {
            var ids = PerkRegistry.parseIds(perks);
            var budget = PerkRegistry.validateBudget(ids);
            if (!budget.valid()) {
                player.method_7353(net.minecraft.class_2561.method_43470(String.join(" ", budget.errors())).method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }

            try {
                String officeId = plugin.getConfig().office().id();
                electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                    try {
                        var candidateOpt = plugin.getPersistence().candidates().findByElectionAndPlayer(election.getId(), player.method_5845());
                        if (candidateOpt.isPresent()) {
                            var candidate = candidateOpt.get();
                            String encoded = PerkRegistry.serialize(ids);
                            plugin.getPersistence().candidates().updatePromises(candidate.getId(), encoded);
                            player.method_7353(net.minecraft.class_2561.method_43470("Promised policies updated. Remaining Policy Points if enacted: " + budget.remaining()).method_27692(net.minecraft.class_124.field_1060), false);
                        } else {
                            player.method_7353(net.minecraft.class_2561.method_43470("You must /kingdom run first.").method_27692(net.minecraft.class_124.field_1061), false);
                        }
                    } catch (SQLException e) {
                        player.method_7353(Messages.error("A server error occurred."), false);
                    }
                }, () -> player.method_7353(Messages.noActiveElection(), false));
            } catch (SQLException e) {
                player.method_7353(Messages.error("A server error occurred."), false);
            }
        });
    }

    private int cmdSetPerksMenu(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> guiService.openPerkSelectionMenu(player, true, 0));
    }

    private int cmdSetPerks(CommandContext<class_2168> ctx, String perks) {
        return withPlayer(ctx, player -> {
            String rulerUuid = officeService.getRuler();
            if (rulerUuid == null || !rulerUuid.equals(player.method_5845())) {
                player.method_7353(net.minecraft.class_2561.method_43470("Only the King can set perks!").method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }
            if (officeService.getActivePerks() != null) {
                player.method_7353(net.minecraft.class_2561.method_43470("Perks have already been set for this term!").method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }
            
            try {
                var result = plugin.getPerkService().activate(player, PerkRegistry.parseIds(perks));
                player.method_7353(net.minecraft.class_2561.method_43470(result.message()).method_27692(result.success() ? net.minecraft.class_124.field_1060 : net.minecraft.class_124.field_1061), false);
            } catch (SQLException e) {
                player.method_7353(Messages.error("Failed to save active perks."), false);
            }
        });
    }

    private int cmdViewPerks(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, guiService::openActivePerksMenu);
    }

    private int cmdInspectPerk(CommandContext<class_2168> ctx, String id) {
        class_2168 src = ctx.getSource();
        PerkDefinition perk = PerkRegistry.find(id).orElse(null);
        if (perk == null) {
            src.method_45068(net.minecraft.class_2561.method_43470("Unknown perk: " + id).method_27692(net.minecraft.class_124.field_1061));
            return 0;
        }
        src.method_45068(net.minecraft.class_2561.method_43470(perk.name() + " [" + perk.category().displayName() + ", " + perk.kind().label() + ", " + perk.cost() + " points]").method_27692(net.minecraft.class_124.field_1065));
        src.method_45068(net.minecraft.class_2561.method_43470(perk.description()).method_27692(net.minecraft.class_124.field_1080));
        return 1;
    }

    private int cmdTrust(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        if (rulerUuid == null) {
            src.method_45068(Messages.noRuler());
            return 1;
        }
        try {
            src.method_45068(net.minecraft.class_2561.method_43470("Trust Score: " + plugin.getPersistence().trust().getScore(rulerUuid) + "/100").method_27692(net.minecraft.class_124.field_1060));
            String history = plugin.getPersistence().trust().recentHistory(rulerUuid, 5);
            if (!history.isBlank()) {
                for (String line : history.split("\\n")) src.method_45068(net.minecraft.class_2561.method_43470(line).method_27692(net.minecraft.class_124.field_1080));
            }
        } catch (SQLException e) {
            src.method_45068(Messages.error("Could not load trust score."));
        }
        return 1;
    }

    private int cmdHelp(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        src.method_45068(Messages.helpHeader());
        src.method_45068(Messages.helpLine("/kingdom status",     "Show current ruler and election phase"));
        src.method_45068(Messages.helpLine("/kingdom origin",     "Show your current Origins assignment"));
        src.method_45068(Messages.helpLine("/kingdom vote",       "Open the voting GUI"));
        src.method_45068(Messages.helpLine("/kingdom candidates", "List current candidates in chat"));
        src.method_45068(Messages.helpLine("/kingdom run [slogan]", "Register your candidacy"));
        src.method_45068(Messages.helpLine("/kingdom promise <perks>", "Set your promised perks"));
        src.method_45068(Messages.helpLine("/kingdom setperks <perks>", "King only: lock in active perks"));
        src.method_45068(Messages.helpLine("/kingdom perks", "View active policies"));
        src.method_45068(Messages.helpLine("/kingdom perk <id>", "Inspect a policy"));
        src.method_45068(Messages.helpLine("/kingdom trust", "View king trust and promise history"));
        src.method_45068(Messages.helpLine("/kingdom laws", "View royal laws"));
        src.method_45068(Messages.helpLine("/kingdom laws book", "Get a current royal law book"));
        src.method_45068(Messages.helpLine("/kingdom laws add <text>", "King only: add a law"));
        src.method_45068(Messages.helpLine("/kingdom laws remove <number>", "King only: remove a law"));
        src.method_45068(Messages.helpLine("/kingdom treasury", "View reserves, taxes, currency, legitimacy, and unrest"));
        src.method_45068(Messages.helpLine("/kingdom treasury deposit <diamonds> <blocks>", "Deposit diamond reserves"));
        src.method_45068(Messages.helpLine("/kingdom treasury redeem <amount>", "Redeem currency for diamond reserves"));
        src.method_45068(Messages.helpLine("/kingdom treasury tax <xp|trade|resource|levy> <rate>", "King only: set tax rates"));
        src.method_45068(Messages.helpLine("/kingdom treasury mint <amount>", "King only: mint currency"));
        src.method_45068(Messages.helpLine("/kingdom treasury spend <category> <amount>", "King only: public or corrupt spending"));
        src.method_45068(Messages.helpLine("/kingdom revolt join|defend", "Join a revolt side when unrest opens the window"));
        src.method_45068(Messages.helpLine("/kingdom summon-guard", "King only: summon temporary royal guards"));
        src.method_45068(Messages.helpLine("/kingdom ruler",      "Show ruler details"));
        src.method_45068(Messages.helpLine("/kingdom menu",       "Open the main kingdom GUI"));
        if (Permissions.isAdmin(src)) {
            src.method_45068(Messages.helpLine("/kingdom admin ...", "Admin commands (you have access)"));
        }
        return 1;
    }

    private int cmdMenu(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, guiService::openMainMenu);
    }

    private int cmdLawsView(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            src.method_45068(net.minecraft.class_2561.method_43470("Royal Laws").method_27695(net.minecraft.class_124.field_1065, net.minecraft.class_124.field_1067));
            String formatted = plugin.getLawService().formatForChat();
            for (String line : formatted.split("\\n")) {
                src.method_45068(net.minecraft.class_2561.method_43470(line).method_27692(net.minecraft.class_124.field_1080));
            }
        } catch (SQLException e) {
            src.method_45068(Messages.error("Could not load royal laws."));
        }
        return 1;
    }

    private int cmdLawsBook(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            try {
                var stack = RoyalLawBookItem.createStack(
                    plugin.getLawService().latestUpdatedAt(),
                    plugin.getLawService().laws()
                );
                if (!player.method_31548().method_7394(stack)) {
                    player.method_7328(stack, false);
                }
                player.method_7353(class_2561.method_43470("Royal law book received. Run /kingdom laws book again for a fresh copy after updates.").method_27692(class_124.field_1060), false);
            } catch (SQLException e) {
                player.method_7353(Messages.error("Could not create royal law book."), false);
            }
        });
    }

    private int cmdLawAdd(CommandContext<class_2168> ctx, String text) {
        return withPlayer(ctx, player -> {
            try {
                plugin.getLawService().addLaw(player, text);
                player.method_7353(net.minecraft.class_2561.method_43470("Law added.").method_27692(net.minecraft.class_124.field_1060), false);
            } catch (Exception e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            }
        });
    }

    private int cmdLawRemove(CommandContext<class_2168> ctx, int number) {
        return withPlayer(ctx, player -> {
            try {
                if (plugin.getLawService().removeLaw(player, number)) {
                    player.method_7353(net.minecraft.class_2561.method_43470("Law removed.").method_27692(net.minecraft.class_124.field_1060), false);
                } else {
                    player.method_7353(Messages.error("No law exists at number " + number + "."), false);
                }
            } catch (Exception e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            }
        });
    }

    private int cmdTreasury(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            TreasuryState s = plugin.getTreasuryService().state();
            src.method_45068(net.minecraft.class_2561.method_43470("Treasury: " + s.rawDiamonds() + " diamonds, " + s.diamondBlocks() + " blocks (" + s.reserveValue() + " diamond reserve)").method_27692(s.reserveHealth().color()));
            String currency = plugin.getTreasuryService().currencyName();
            src.method_45068(net.minecraft.class_2561.method_43470(currency + ": " + s.currencySupply() + " supply, reserve ratio " + Math.round(s.reserveRatio() * 100.0) + "%, " + s.reserveHealth().label()).method_27692(s.reserveHealth().color()));
            src.method_45068(net.minecraft.class_2561.method_43470("Taxes: XP " + s.xpTaxRate() + "%, trade " + s.tradeTaxRate() + "%, resource " + s.resourceTitheRate() + "%, emergency levy " + s.emergencyLevyRate() + "%").method_27692(net.minecraft.class_124.field_1065));
            src.method_45068(net.minecraft.class_2561.method_43470("Trust/Legitimacy/Heat/Unrest: " + trustScore() + "/100, " + s.legitimacy() + "/100, " + s.corruptionHeat() + "/100, " + s.unrest() + "/100 (" + s.unrestBand().label() + ")").method_27692(s.unrestBand().color()));
            if (src.method_9228() instanceof class_3222 player) {
                src.method_45068(net.minecraft.class_2561.method_43470("Your " + currency + ": " + plugin.getTreasuryService().balance(player.method_5845())).method_27692(net.minecraft.class_124.field_1075));
            }
            if (s.revoltActive()) src.method_45068(net.minecraft.class_2561.method_43470("Revolt active: capture the capital at " + plugin.getTreasuryService().capitalText() + ". Progress " + s.captureProgress() + "%").method_27692(net.minecraft.class_124.field_1079));
        } catch (SQLException e) {
            src.method_45068(Messages.error("Could not load treasury."));
        }
        return 1;
    }

    private int cmdTreasuryDeposit(CommandContext<class_2168> ctx, int diamonds, int blocks) {
        return withPlayer(ctx, player -> {
            try {
                plugin.getTreasuryService().depositReserves(player, diamonds, blocks);
            } catch (SQLException e) {
                player.method_7353(Messages.error("Could not deposit reserves."), false);
            }
        });
    }

    private int cmdRedeem(CommandContext<class_2168> ctx, int amount) {
        return withPlayer(ctx, player -> {
            try {
                plugin.getTreasuryService().redeem(player, amount);
            } catch (SQLException e) {
                player.method_7353(Messages.error("Could not redeem Crowns."), false);
            }
        });
    }

    private int cmdSetTax(CommandContext<class_2168> ctx, String channel, int rate) {
        return withPlayer(ctx, player -> {
            try {
                plugin.getTreasuryService().setTax(player, channel, rate);
            } catch (Exception e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            }
        });
    }

    private int cmdMint(CommandContext<class_2168> ctx, int amount, boolean emergency) {
        return withPlayer(ctx, player -> {
            try {
                plugin.getTreasuryService().mint(player, amount, emergency);
            } catch (Exception e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            }
        });
    }

    private int cmdSpend(CommandContext<class_2168> ctx, String category, int amount) {
        return withPlayer(ctx, player -> {
            try {
                SpendingCategory c = SpendingCategory.valueOf(category.toUpperCase());
                plugin.getTreasuryService().spend(player, c, amount);
            } catch (IllegalArgumentException e) {
                player.method_7353(Messages.error("Categories: public_works, military, relief, infrastructure, festival, stabilization, palace, siphon"), false);
            } catch (Exception e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            }
        });
    }

    private int cmdRevolt(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            TreasuryState s = plugin.getTreasuryService().state();
            src.method_45068(net.minecraft.class_2561.method_43470("Revolt: " + (s.revoltActive() ? "ACTIVE" : "inactive") + ", unrest " + s.unrest() + "/100, capture " + s.captureProgress() + "%").method_27692(s.revoltActive() ? net.minecraft.class_124.field_1079 : net.minecraft.class_124.field_1080));
            src.method_45068(net.minecraft.class_2561.method_43470("Capital objective: stand near " + plugin.getTreasuryService().capitalText() + " during revolt. Rebels progress only if they outnumber loyalists in the zone.").method_27692(net.minecraft.class_124.field_1054));
        } catch (SQLException e) {
            src.method_45068(Messages.error("Could not load revolt status."));
        }
        return 1;
    }

    private int cmdJoinRevolt(CommandContext<class_2168> ctx, String side) {
        return withPlayer(ctx, player -> {
            try {
                plugin.getTreasuryService().joinRevolt(player, side);
            } catch (SQLException e) {
                player.method_7353(Messages.error("Could not join revolt."), false);
            }
        });
    }

    private int cmdStartElection(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            String rulerUuid = officeService.getRuler();
            if (rulerUuid == null || !rulerUuid.equals(player.method_5845())) {
                player.method_7353(net.minecraft.class_2561.method_43470("Only the King can start elections!").method_27692(net.minecraft.class_124.field_1061), false);
                return;
            }
            try {
                plugin.startElectionAndSchedule(plugin.getConfig().office().id());
                player.method_7353(Messages.electionStarted(), false);
            } catch (ElectionException e) {
                player.method_7353(Messages.error(e.getMessage()), false);
            } catch (SQLException e) {
                KingdomsPlugin.LOGGER.error("Start election failed", e);
                player.method_7353(Messages.error("A server error occurred."), false);
            }
        });
    }

    private int cmdSummonGuard(CommandContext<class_2168> ctx) {
        return withPlayer(ctx, player -> {
            if (!plugin.getLawService().isKing(player)) {
                player.method_7353(class_2561.method_43470("Only the King can summon the royal guard.").method_27692(class_124.field_1061), false);
                return;
            }

            long now = System.currentTimeMillis();
            long nextUse = royalGuardCooldowns.getOrDefault(player.method_5667(), 0L);
            if (now < nextUse) {
                long remainingSeconds = Math.max(1L, (nextUse - now + 999L) / 1000L);
                player.method_7353(class_2561.method_43470("Royal Guard is on cooldown for " + formatDuration(remainingSeconds) + ".").method_27692(class_124.field_1061), false);
                return;
            }

            summonRoyalGuards(player);
            healKing(player);
            royalGuardCooldowns.put(player.method_5667(), now + ROYAL_GUARD_COOLDOWN_MILLIS);
            player.method_7353(class_2561.method_43470("The royal guard answers your call.").method_27692(class_124.field_1065), false);
        });
    }

    // ------------------------------------------------------------------
    // Admin command handlers
    // ------------------------------------------------------------------

    private int adminStartElection(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            plugin.startElectionAndSchedule(plugin.getConfig().office().id());
            src.method_45068(Messages.electionStarted());
        } catch (ElectionException e) {
            src.method_45068(Messages.error(e.getMessage()));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Start election failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminEndElection(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                try {
                    plugin.getScheduleService().forceAdvancePhase(election.getId());
                    src.method_45068(Messages.electionEnded());
                } catch (Exception e) {
                    src.method_45068(Messages.error("Failed to end election: " + e.getMessage()));
                }
            }, () -> src.method_45068(Messages.noActiveElection()));
        } catch (SQLException e) {
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminSetRuler(CommandContext<class_2168> ctx, class_3222 target) {
        class_2168 src = ctx.getSource();
        try {
            officeService.assignRuler(target.method_5667());
            src.method_45068(Messages.rulerSet(target.method_5477().getString()));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Set ruler failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminRemoveRuler(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            officeService.removeRuler(OfficeService.RemovalReason.FORCED);
            src.method_45068(Messages.rulerRemoved());
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Remove ruler failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminForceTransfer(CommandContext<class_2168> ctx, class_3222 target) {
        class_2168 src = ctx.getSource();
        String currentRulerUuid = officeService.getRuler();
        if (currentRulerUuid == null) {
            // No current ruler — just assign
            try {
                officeService.assignRuler(target.method_5667());
                src.method_45068(Messages.rulerSet(target.method_5477().getString()));
            } catch (SQLException e) {
                src.method_45068(Messages.error("A server error occurred."));
            }
            return 1;
        }
        try {
            transferService.transferOffice(UUID.fromString(currentRulerUuid), target.method_5667());
            src.method_45068(Messages.rulerSet(target.method_5477().getString()));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Force transfer failed", e);
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminGiveOrb(CommandContext<class_2168> ctx, class_3222 target) {
        class_2168 src = ctx.getSource();
        try {
            transferService.giveOriginOrb(target);
            src.method_45068(Messages.orbGiven(target.method_5477().getString()));
        } catch (Exception e) {
            KingdomsPlugin.LOGGER.error("Give orb failed", e);
            src.method_45068(Messages.error("Failed to give orb: " + e.getMessage()));
        }
        return 1;
    }

    private int adminSetPhase(CommandContext<class_2168> ctx, String phase) {
        class_2168 src = ctx.getSource();
        try {
            ElectionPhase nextPhase = ElectionPhase.valueOf(phase.toUpperCase());
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                try {
                    var updated = electionService.setPhase(election.getId(), nextPhase);
                    if (nextPhase == ElectionPhase.COMPLETE || nextPhase == ElectionPhase.IDLE) {
                        plugin.getScheduleService().cancelTransition(updated.getId());
                    } else {
                        plugin.getScheduleService().scheduleNextTransition(updated);
                    }
                    src.method_45068(Messages.phaseSet(nextPhase.name()));
                } catch (SQLException | ElectionException e) {
                    src.method_45068(Messages.error("A server error occurred."));
                }
            }, () -> src.method_45068(Messages.noActiveElection()));
        } catch (IllegalArgumentException e) {
            src.method_45068(Messages.error("Unknown phase: " + phase));
        } catch (SQLException e) {
            src.method_45068(Messages.error("A server error occurred."));
        }
        return 1;
    }

    private int adminReload(CommandContext<class_2168> ctx) {
        plugin.reloadConfig();
        ctx.getSource().method_45068(Messages.configReloaded());
        return 1;
    }

    private int adminDebugSync(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        String rulerUuid = officeService.getRuler();
        if (rulerUuid == null) {
            src.method_45068(Messages.noRulerToSync());
            return 1;
        }
        class_3222 ruler = src.method_9211().method_3760().method_14602(UUID.fromString(rulerUuid));
        if (ruler != null) {
            transferService.validateSync(ruler);
            src.method_45068(Messages.debugSynced());
        } else {
            src.method_45068(Messages.error("Ruler is offline; sync will apply on next login."));
        }
        return 1;
    }

    private int adminDbStatus(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            int players = plugin.getPersistence().players().findAll().size();
            int elections = plugin.getPersistence().elections().findByOfficeId(officeId).size();
            var treasury = plugin.getTreasuryService().state();
            src.method_45068(net.minecraft.class_2561.method_43470("DB OK: " + players + " players, " + elections + " elections for office '" + officeId + "'.").method_27692(net.minecraft.class_124.field_1060));
            src.method_45068(net.minecraft.class_2561.method_43470("Treasury row OK: reserve " + treasury.reserveValue() + ", supply " + treasury.currencySupply() + ".").method_27692(net.minecraft.class_124.field_1080));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("DB status check failed", e);
            src.method_45068(Messages.error("Database check failed: " + e.getMessage()));
        }
        return 1;
    }

    private int adminElectionStatus(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            var current = electionService.getCurrentElection(officeId);
            if (current.isEmpty()) {
                src.method_45068(Messages.noActiveElection());
                return 1;
            }
            var e = current.get();
            src.method_45068(net.minecraft.class_2561.method_43470("Election " + e.getId() + ": " + e.getStatus() + ", winner=" + e.getWinnerUuid()).method_27692(net.minecraft.class_124.field_1065));
            src.method_45068(net.minecraft.class_2561.method_43470("Nomination opens " + e.getNominationOpensAt() + ", voting opens " + e.getVotingOpensAt() + ", voting closes " + e.getVotingClosesAt()).method_27692(net.minecraft.class_124.field_1080));
            src.method_45068(net.minecraft.class_2561.method_43470("Candidates: " + electionService.getCandidates(e.getId()).size()).method_27692(net.minecraft.class_124.field_1080));
        } catch (SQLException e) {
            src.method_45068(Messages.error("Could not load election status."));
        }
        return 1;
    }

    private int adminTreasuryLedger(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            var rows = plugin.getPersistence().treasury().recentPublicLedger(plugin.getConfig().office().id(), 10);
            src.method_45068(net.minecraft.class_2561.method_43470("Recent public treasury ledger").method_27692(net.minecraft.class_124.field_1075));
            if (rows.isEmpty()) {
                src.method_45068(net.minecraft.class_2561.method_43470("No public ledger entries.").method_27692(net.minecraft.class_124.field_1080));
            }
            for (String row : rows) {
                src.method_45068(net.minecraft.class_2561.method_43470(row).method_27692(net.minecraft.class_124.field_1080));
            }
        } catch (SQLException e) {
            src.method_45068(Messages.error("Could not load treasury ledger."));
        }
        return 1;
    }

    private int adminRepairOfficeState(CommandContext<class_2168> ctx) {
        class_2168 src = ctx.getSource();
        try {
            String officeId = plugin.getConfig().office().id();
            var current = electionService.getCurrentElection(officeId);
            var state = plugin.getPersistence().officeStates().findByOfficeId(officeId)
                .orElseGet(() -> new com.example.kingdoms.db.model.OfficeState(officeId, null, null, null, 0L, 0L, null, null));
            state.setPhase(current.map(com.example.kingdoms.db.model.Election::getStatus).orElse(ElectionPhase.IDLE.name()));
            plugin.getPersistence().officeStates().save(state);
            src.method_45068(net.minecraft.class_2561.method_43470("Office state repaired: phase=" + state.getPhase()).method_27692(net.minecraft.class_124.field_1060));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Office state repair failed", e);
            src.method_45068(Messages.error("Could not repair office state."));
        }
        return 1;
    }

    // ------------------------------------------------------------------
    // Utilities
    // ------------------------------------------------------------------

    /** Runs an action requiring a player source; sends an error and returns 0 if not a player. */
    private int withPlayer(CommandContext<class_2168> ctx, java.util.function.Consumer<class_3222> action) {
        if (!(ctx.getSource().method_9228() instanceof class_3222 player)) {
            ctx.getSource().method_45068(Messages.error("This command can only be used by players."));
            return 0;
        }
        action.accept(player);
        return 1;
    }

    private String resolveOrUuid(class_2168 src, String uuid) {
        try {
            class_3222 online = src.method_9211().method_3760().method_14602(UUID.fromString(uuid));
            if (online != null) return online.method_5477().getString();
            return plugin.getPersistence().players().findByUuid(uuid)
                .map(p -> p.getUsername() != null ? p.getUsername() : uuid)
                .orElse(uuid);
        } catch (Exception e) {
            return uuid;
        }
    }

    private static String displayOrigin(String originId) {
        if (originId == null || originId.isBlank() || "origins:empty".equals(originId)) {
            return "none";
        }
        return originId;
    }

    private int trustScore() {
        String rulerUuid = officeService.getRuler();
        if (rulerUuid == null) return 50;
        try {
            return plugin.getPersistence().trust().getScore(rulerUuid);
        } catch (SQLException e) {
            return 50;
        }
    }

    private void summonRoyalGuards(class_3222 player) {
        class_3218 world = player.method_51469();
        long expireAt = world.method_8510() + ROYAL_GUARD_LIFETIME_TICKS;
        for (int i = 0; i < ROYAL_GUARD_COUNT; i++) {
            class_1493 guard = class_1299.field_6055.method_5883(world);
            if (guard == null) continue;

            double angle = (Math.PI * 2.0 * i) / ROYAL_GUARD_COUNT;
            double x = player.method_23317() + Math.cos(angle) * 2.0;
            double z = player.method_23321() + Math.sin(angle) * 2.0;
            guard.method_5808(x, player.method_23318(), z, player.method_36454(), 0.0F);
            guard.method_6173(true);
            guard.method_6174(player.method_5667());
            guard.method_5665(class_2561.method_43470("Royal Guard").method_27692(class_124.field_1065));
            guard.method_5880(true);
            guard.method_6092(new class_1293(class_1294.field_5910, ROYAL_GUARD_LIFETIME_TICKS, 4, false, true, true));
            guard.method_6092(new class_1293(class_1294.field_5907, ROYAL_GUARD_LIFETIME_TICKS, 2, false, true, true));
            guard.method_6092(new class_1293(class_1294.field_5904, ROYAL_GUARD_LIFETIME_TICKS, 1, false, true, true));
            guard.method_6092(new class_1293(class_1294.field_5924, ROYAL_GUARD_LIFETIME_TICKS, 2, false, true, true));
            guard.method_6033(guard.method_6063());

            world.method_8649(guard);
            activeRoyalGuards.put(guard.method_5667(), expireAt);
        }
    }

    private void healKing(class_3222 player) {
        player.method_6025(12.0F);
        player.method_6092(new class_1293(class_1294.field_5924, 20 * 10, 1, false, true, true));
        player.method_6092(new class_1293(class_1294.field_5907, 20 * 5, 1, false, true, true));
    }

    private void tickRoyalGuards(MinecraftServer server) {
        if (activeRoyalGuards.isEmpty()) return;
        long now = server.method_30002().method_8510();
        Iterator<Map.Entry<UUID, Long>> iterator = activeRoyalGuards.entrySet().iterator();
        while (iterator.hasNext()) {
            Map.Entry<UUID, Long> entry = iterator.next();
            if (now < entry.getValue()) continue;
            discardEntity(server, entry.getKey());
            iterator.remove();
        }
    }

    private void discardEntity(MinecraftServer server, UUID uuid) {
        for (class_3218 world : server.method_3738()) {
            class_1297 entity = world.method_14190(uuid);
            if (entity != null) {
                entity.method_31472();
                return;
            }
        }
    }

    private static String formatDuration(long totalSeconds) {
        long minutes = totalSeconds / 60L;
        long seconds = totalSeconds % 60L;
        if (minutes <= 0L) return seconds + "s";
        if (seconds == 0L) return minutes + "m";
        return minutes + "m " + seconds + "s";
    }
}
