package com.example.kingdoms.ui.gui;

import com.example.kingdoms.KingdomsPlugin;
import com.example.kingdoms.db.model.Candidate;
import com.example.kingdoms.election.ElectionException;
import com.example.kingdoms.election.ElectionPhase;
import com.example.kingdoms.election.ElectionService;
import com.example.kingdoms.origin.OfficeService;
import com.example.kingdoms.perk.PerkCategory;
import com.example.kingdoms.perk.PerkDefinition;
import com.example.kingdoms.perk.PerkRegistry;
import com.example.kingdoms.perk.PerkRegistry.BudgetResult;
import com.example.kingdoms.treasury.TreasuryState;
import com.example.kingdoms.ui.AnnouncementService;
import com.example.kingdoms.ui.Messages;
import net.minecraft.class_124;
import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2487;
import net.minecraft.class_2495;
import net.minecraft.class_2499;
import net.minecraft.class_2519;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_747;
import net.minecraft.server.MinecraftServer;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

/**
 * Builds and opens inventory GUI menus for political interactions.
 * Each open* method constructs an inventory, populates it, and opens it for the player.
 */
public final class GuiService {

    private final ElectionService electionService;
    private final OfficeService officeService;
    private final AnnouncementService announcementService;
    private final KingdomsPlugin plugin;
    
    private final java.util.Map<UUID, java.util.Set<String>> activePerkSelections = new java.util.concurrent.ConcurrentHashMap<>();

    public GuiService(
        ElectionService electionService,
        OfficeService officeService,
        AnnouncementService announcementService,
        KingdomsPlugin plugin
    ) {
        this.electionService    = electionService;
        this.officeService      = officeService;
        this.announcementService = announcementService;
        this.plugin             = plugin;
    }

    // ------------------------------------------------------------------
    // a. Main politics menu
    // ------------------------------------------------------------------

    public void openMainMenu(class_3222 player) {
        class_1277 inv = new class_1277(9 * 3);
        String rulerUuid  = officeService.getRuler();
        String phase      = officeService.getPhase();
        long   termEnd    = officeService.getTermEnd();

        // Slot 4 — current ruler skull
        if (rulerUuid != null) {
            MinecraftServer server = player.method_5682();
            class_3222 rulerPlayer = server != null
                ? server.method_3760().method_14602(UUID.fromString(rulerUuid)) : null;
            String rulerName = rulerPlayer != null ? rulerPlayer.method_5477().getString() : rulerUuid;
            inv.method_5447(4, headStack(rulerUuid, rulerName,
                List.of(Messages.termEndLine(termEnd), Messages.phaseLine(phase))));
        } else {
            inv.method_5447(4, namedStack(class_1802.field_8077,
                class_2561.method_43470("No Ruler").method_27692(class_124.field_1080),
                List.of(class_2561.method_43470("The throne is vacant.").method_27692(class_124.field_1063))));
        }

        // Slot 11 — Vote button
        ElectionPhase electionPhase = ElectionPhase.fromString(phase);
        if (electionPhase == ElectionPhase.VOTING) {
            inv.method_5447(11, namedStack(class_1802.field_8581,
                Messages.guiVoteButton(),
                List.of(class_2561.method_43470("Click to see candidates and vote.").method_27692(class_124.field_1080))));
        } else {
            inv.method_5447(11, namedStack(class_1802.field_8871,
                Messages.guiVoteButton(),
                List.of(Messages.guiPhaseNotice(phase))));
        }

        // Slot 13 — View Candidates
        inv.method_5447(13, namedStack(class_1802.field_8529,
            Messages.guiViewCandidatesButton(),
            List.of(class_2561.method_43470("See who is running.").method_27692(class_124.field_1080))));

        // Slot 15 — Ruler Panel (only for current ruler)
        if (rulerUuid != null && rulerUuid.equals(player.method_5845())) {
            inv.method_5447(15, namedStack(class_1802.field_8862,
                Messages.guiRulerPanelButton(),
                List.of(class_2561.method_43470("Access your administrative panel.").method_27692(class_124.field_1080))));
        }

        // Slot 14 — Run for Office or Manage Promises
        if (electionPhase == ElectionPhase.NOMINATION || electionPhase == ElectionPhase.CAMPAIGN) {
            boolean isCandidate = false;
            try {
                String officeId = plugin.getConfig().office().id();
                var electionOpt = electionService.getCurrentElection(officeId);
                if (electionOpt.isPresent()) {
                    long electionId = electionOpt.get().getId();
                    isCandidate = plugin.getPersistence().candidates()
                        .findByElectionAndPlayer(electionId, player.method_5845()).isPresent();
                }
            } catch (SQLException ignored) {}

            if (isCandidate) {
                inv.method_5447(14, namedStack(class_1802.field_8674,
                    class_2561.method_43470("Manage Promises").method_27695(class_124.field_1065, class_124.field_1067),
                    List.of(class_2561.method_43470("Update your campaign promises.").method_27692(class_124.field_1080))));
            } else {
                inv.method_5447(14, namedStack(class_1802.field_8407,
                    class_2561.method_43470("Run for Office").method_27695(class_124.field_1065, class_124.field_1067),
                    List.of(class_2561.method_43470("Register as a candidate.").method_27692(class_124.field_1080))));
            }
        }

        // Slot 17 — History
        inv.method_5447(17, namedStack(class_1802.field_8674,
            Messages.guiHistoryButton(),
            List.of(class_2561.method_43470("View kingdom history.").method_27692(class_124.field_1080))));

        inv.method_5447(10, namedStack(class_1802.field_8477,
            class_2561.method_43470("Treasury").method_27695(class_124.field_1075, class_124.field_1067),
            List.of(class_2561.method_43470("View reserves, Crowns, taxes, and unrest.").method_27692(class_124.field_1080))));

        openScreen(player, inv, 3, Messages.guiTitle("Kingdom Politics"), (slot, clicker) -> {
            switch (slot) {
                case 11 -> {
                    if (ElectionPhase.fromString(officeService.getPhase()) == ElectionPhase.VOTING) {
                        openCandidateList(clicker);
                    } else {
                        clicker.method_7353(Messages.votingNotOpen(), false);
                    }
                }
                case 13 -> openCandidateList(clicker);
                case 10 -> openTreasuryMenu(clicker);
                case 14 -> {
                    if (ElectionPhase.fromString(officeService.getPhase()) == ElectionPhase.NOMINATION ||
                        ElectionPhase.fromString(officeService.getPhase()) == ElectionPhase.CAMPAIGN) {
                        
                        boolean isCandidate = false;
                        try {
                            String officeId = plugin.getConfig().office().id();
                            var electionOpt = electionService.getCurrentElection(officeId);
                            if (electionOpt.isPresent()) {
                                isCandidate = plugin.getPersistence().candidates()
                                    .findByElectionAndPlayer(electionOpt.get().getId(), clicker.method_5845()).isPresent();
                            }
                        } catch (SQLException ignored) {}
                        
                        if (isCandidate) {
                            openPerkSelectionMenu(clicker, false, 0);
                        } else {
                            clicker.method_7346();
                            MinecraftServer server = clicker.method_5682();
                            if (server != null) {
                                server.method_3734().method_44252(clicker.method_5671(), "kingdom run");
                            }
                        }
                    }
                }
                case 15 -> {
                    if (officeService.getRuler() != null
                            && officeService.getRuler().equals(clicker.method_5845())) {
                        openRulerPanel(clicker);
                    }
                }
                case 17 -> openHistoryMenu(clicker, 0);
                default -> {}
            }
        });
    }

    public void openTreasuryMenu(class_3222 player) {
        class_1277 inv = new class_1277(27);
        try {
            var s = plugin.getTreasuryService().state();
            int balance = plugin.getTreasuryService().balance(player.method_5845());
            inv.method_5447(4, namedStack(class_1802.field_8603,
                class_2561.method_43470("Diamond Reserves").method_27695(s.reserveHealth().color(), class_124.field_1067),
                List.of(
                    class_2561.method_43470(s.rawDiamonds() + " diamonds, " + s.diamondBlocks() + " diamond blocks").method_27692(class_124.field_1068),
                    class_2561.method_43470(s.reserveValue() + " diamond-equivalent reserve").method_27692(class_124.field_1075),
                    class_2561.method_43470("State: " + s.reserveHealth().label()).method_27692(s.reserveHealth().color())
                )));
            String currency = plugin.getTreasuryService().currencyName();
            inv.method_5447(10, namedStack(class_1802.field_8407,
                class_2561.method_43470(currency).method_27695(class_124.field_1065, class_124.field_1067),
                List.of(
                    class_2561.method_43470("Supply: " + s.currencySupply()).method_27692(class_124.field_1068),
                    class_2561.method_43470("Reserve ratio: " + Math.round(s.reserveRatio() * 100.0) + "%").method_27692(s.reserveHealth().color()),
                    class_2561.method_43470("Your balance: " + balance).method_27692(class_124.field_1075)
                )));
            inv.method_5447(12, namedStack(class_1802.field_8674,
                class_2561.method_43470("Tax Policy").method_27695(class_124.field_1054, class_124.field_1067),
                List.of(
                    class_2561.method_43470("XP: " + s.xpTaxRate() + "%").method_27692(class_124.field_1080),
                    class_2561.method_43470("Trade: " + s.tradeTaxRate() + "%").method_27692(class_124.field_1080),
                    class_2561.method_43470("Resource tithe: " + s.resourceTitheRate() + "%").method_27692(class_124.field_1080),
                    class_2561.method_43470("Emergency levy: " + s.emergencyLevyRate() + "%").method_27692(class_124.field_1061)
                )));
            inv.method_5447(14, namedStack(class_1802.field_8725,
                class_2561.method_43470("Political Stability").method_27695(s.unrestBand().color(), class_124.field_1067),
                List.of(
                    class_2561.method_43470("Legitimacy: " + s.legitimacy() + "/100").method_27692(class_124.field_1060),
                    class_2561.method_43470("Corruption Heat: " + s.corruptionHeat() + "/100").method_27692(class_124.field_1079),
                    class_2561.method_43470("Unrest: " + s.unrest() + "/100 (" + s.unrestBand().label() + ")").method_27692(s.unrestBand().color()),
                    class_2561.method_43470("Revolt: " + (s.revoltActive() ? "OPEN" : "closed")).method_27692(s.revoltActive() ? class_124.field_1079 : class_124.field_1080)
                )));
            inv.method_5447(16, namedStack(class_1802.field_16315,
                class_2561.method_43470("Public Ledger").method_27695(class_124.field_1075, class_124.field_1067),
                plugin.getPersistence().treasury().recentPublicLedger(plugin.getConfig().office().id(), 5).stream()
                    .<class_2561>map(line -> class_2561.method_43470(line).method_27692(class_124.field_1080))
                    .toList()));
            if (player.method_5845().equals(officeService.getRuler())) {
                inv.method_5447(22, namedStack(class_1802.field_8695,
                    class_2561.method_43470("Fiscal Controls").method_27695(class_124.field_1065, class_124.field_1067),
                    List.of(
                        class_2561.method_43470("Use /kingdom treasury tax <channel> <rate>").method_27692(class_124.field_1080),
                        class_2561.method_43470("Use /kingdom treasury mint <amount>").method_27692(class_124.field_1080),
                        class_2561.method_43470("Use /kingdom treasury spend <category> <amount>").method_27692(class_124.field_1080)
                    )));
            }
        } catch (SQLException e) {
            inv.method_5447(13, namedStack(class_1802.field_8077, class_2561.method_43470("Treasury unavailable").method_27692(class_124.field_1061), List.of()));
        }
        openScreen(player, inv, 3, class_2561.method_43470("Kingdom Treasury"), (slot, clicker) -> {});
    }

    // ------------------------------------------------------------------
    // b. Candidate list menu
    // ------------------------------------------------------------------

    public void openCandidateList(class_3222 player) {
        List<Candidate> candidates = loadCandidates();
        int rows = Math.max(1, (int) Math.ceil((candidates.size() + 1) / 9.0));
        rows = Math.min(rows, 6);

        class_1277 inv = new class_1277(rows * 9);
        for (int i = 0; i < candidates.size() && i < rows * 9; i++) {
            Candidate c = candidates.get(i);
            String name   = resolvePlayerName(player, c.getPlayerUuid());
            String slogan = c.getSlogan();
            String perks = c.getPromisedPerks();
            
            java.util.List<class_2561> lore = new java.util.ArrayList<>();
            if (slogan != null && !slogan.isBlank()) {
                lore.add(class_2561.method_43470(slogan).method_27692(class_124.field_1080));
            }
            if (perks != null && !perks.isBlank()) {
                lore.add(class_2561.method_43470("Promises: " + perks).method_27692(class_124.field_1075));
            }
            inv.method_5447(i, headStack(c.getPlayerUuid(), name, lore));
        }

        if (candidates.isEmpty()) {
            inv.method_5447(4, namedStack(class_1802.field_8077,
                class_2561.method_43470("No candidates yet.").method_27692(class_124.field_1080),
                List.of()));
        }

        openScreen(player, inv, rows, Messages.guiTitle("Candidates"), (slot, clicker) -> {
            if (slot < candidates.size()) {
                openVoteConfirmation(clicker, candidates.get(slot));
            }
        });
    }

    // ------------------------------------------------------------------
    // c. Vote confirmation menu
    // ------------------------------------------------------------------

    public void openVoteConfirmation(class_3222 player, Candidate candidate) {
        class_1277 inv = new class_1277(9);

        String name = resolvePlayerName(player, candidate.getPlayerUuid());
        String slogan = candidate.getSlogan();
        String perks = candidate.getPromisedPerks();
        
        java.util.List<class_2561> lore = new java.util.ArrayList<>();
        if (slogan != null && !slogan.isBlank()) {
            lore.add(class_2561.method_43470(slogan).method_27692(class_124.field_1056));
        }
        if (perks != null && !perks.isBlank()) {
            lore.add(class_2561.method_43470("Promises: " + perks).method_27692(class_124.field_1075));
        }

        inv.method_5447(4, headStack(candidate.getPlayerUuid(), name, lore));

        inv.method_5447(2, namedStack(class_1802.field_8581,
            Messages.guiConfirmVote(),
            List.of(class_2561.method_43470("Confirm your vote for " + name + ".").method_27692(class_124.field_1080))));

        inv.method_5447(6, namedStack(class_1802.field_8879,
            Messages.guiCancel(),
            List.of(class_2561.method_43470("Go back.").method_27692(class_124.field_1080))));

        openScreen(player, inv, 1, Messages.guiTitle("Confirm Vote"), (slot, clicker) -> {
            if (slot == 2) {
                clicker.method_7346();
                castVoteFor(clicker, candidate);
            } else if (slot == 6) {
                clicker.method_7346();
                openCandidateList(clicker);
            }
        });
    }

    // ------------------------------------------------------------------
    // d. Ruler panel menu
    // ------------------------------------------------------------------

    public void openRulerPanel(class_3222 player) {
        if (!player.method_5845().equals(officeService.getRuler())) {
            player.method_7353(Messages.noPermission(), false);
            return;
        }

        class_1277 inv = new class_1277(9 * 3);
        String rulerName = player.method_5477().getString();
        long   termEnd   = officeService.getTermEnd();
        String originId  = plugin.getConfig().originMode().kingOriginId();

        // Slot 4 — ruler info skull
        inv.method_5447(4, headStack(player.method_5845(), rulerName,
            List.of(
                Messages.termEndLine(termEnd),
                class_2561.method_43470("Origin: " + originId).method_27692(class_124.field_1075)
            )));

        // Slot 11 — Broadcast Speech
        inv.method_5447(11, namedStack(class_1802.field_8407,
            Messages.guiBroadcastSpeech(),
            List.of(class_2561.method_43470("Broadcast a message to the entire server.").method_27692(class_124.field_1080))));

        // Slot 13 — Set Active Perks
        inv.method_5447(13, namedStack(class_1802.field_8687,
            class_2561.method_43470("Set Active Policies").method_27692(class_124.field_1060),
            List.of(class_2561.method_43470("Spend up to 20 Policy Points.").method_27692(class_124.field_1080))));

        // Slot 14 — Abdicate
        inv.method_5447(14, namedStack(class_1802.field_8594,
            class_2561.method_43470("Step Down").method_27695(class_124.field_1061, class_124.field_1067),
            List.of(class_2561.method_43470("Abdicate the throne.").method_27692(class_124.field_1080))));

        // Slot 15 — Start Election
        inv.method_5447(15, namedStack(class_1802.field_8668,
            class_2561.method_43470("Start Election").method_27695(class_124.field_1065, class_124.field_1067),
            List.of(class_2561.method_43470("Begin a new election cycle.").method_27692(class_124.field_1080))));

        // Slot 16 — Empty
        inv.method_5447(16, namedStack(class_1802.field_8871,
            class_2561.method_43470(""),
            List.of()));

        openScreen(player, inv, 3, Messages.guiTitle("Ruler Panel"), (slot, clicker) -> {
            if (slot == 11) {
                clicker.method_7346();
                plugin.getEventListeners().setPendingSpeech(clicker.method_5667());
                clicker.method_7353(Messages.speechPrompt(), false);
            } else if (slot == 13) {
                openPerkSelectionMenu(clicker, true, 0);
            } else if (slot == 14) {
                clicker.method_7346();
                try {
                    officeService.removeRuler(com.example.kingdoms.origin.OfficeService.RemovalReason.ABDICATION);
                    clicker.method_7353(class_2561.method_43470("You have abdicated the throne.").method_27692(class_124.field_1054), false);
                } catch (SQLException e) {
                    clicker.method_7353(Messages.error("A server error occurred."), false);
                }
            } else if (slot == 15) {
                clicker.method_7346();
                MinecraftServer server = clicker.method_5682();
                if (server != null) {
                    server.method_3734().method_44252(clicker.method_5671(), "kingdom start-election");
                }
            }
        });
    }

    // ------------------------------------------------------------------
    // e. Perk selection menu
    // ------------------------------------------------------------------

    public void openPerkSelectionMenu(class_3222 player, boolean isSetPerks, int page) {
        java.util.Set<String> selected = activePerkSelections.computeIfAbsent(player.method_5667(), k -> new java.util.HashSet<>());
        java.util.List<PerkDefinition> perks = PerkRegistry.all();
        int totalPerks = perks.size();
        int perksPerPage = 45;
        int totalPages = (int) Math.ceil((double) totalPerks / perksPerPage);
        
        class_1277 inv = new class_1277(54);
        
        int startIndex = page * perksPerPage;
        int endIndex = Math.min(startIndex + perksPerPage, totalPerks);
        java.util.Set<PerkCategory> selectedCategories = selected.stream()
            .map(id -> PerkRegistry.find(id).map(PerkDefinition::category).orElse(null))
            .filter(java.util.Objects::nonNull)
            .collect(java.util.stream.Collectors.toSet());
        
        for (int i = startIndex; i < endIndex; i++) {
            PerkDefinition perk = perks.get(i);
            boolean isSelected = selected.contains(perk.id());
            boolean blockedByCategory = !isSelected && selectedCategories.contains(perk.category());
            
            class_1799 stack = namedStack(blockedByCategory ? class_1802.field_8298 : (perk.category() == PerkCategory.CORRUPTION ? class_1802.field_8725 : perk.icon()),
                class_2561.method_43470(perk.name()).method_27692(perk.category() == PerkCategory.CORRUPTION ? class_124.field_1061 : (isSelected ? class_124.field_1060 : class_124.field_1054)),
                List.of(
                    class_2561.method_43470(perk.id()).method_27692(class_124.field_1063),
                    class_2561.method_43470(perk.category().displayName() + " - " + perk.kind().label() + " (" + perk.cost() + " points)").method_27692(class_124.field_1075),
                    class_2561.method_43470(perk.description()).method_27692(class_124.field_1080),
                    class_2561.method_43470(blockedByCategory ? "Category already selected" : (isSelected ? "Click to deselect" : "Click to select")).method_27692(blockedByCategory ? class_124.field_1061 : class_124.field_1068)
                ));
            if (isSelected) {
                stack.method_7978(net.minecraft.class_1893.field_9119, 1);
                stack.method_7948().method_10569("HideFlags", 1); // Hide enchantments
            }
            inv.method_5447(i - startIndex, stack);
        }
        
        // Navigation & Confirmation
        if (page > 0) {
            inv.method_5447(45, namedStack(class_1802.field_8107, class_2561.method_43470("Previous Page").method_27692(class_124.field_1068), List.of()));
        }
        if (page < totalPages - 1) {
            inv.method_5447(53, namedStack(class_1802.field_8107, class_2561.method_43470("Next Page").method_27692(class_124.field_1068), List.of()));
        }
        
        inv.method_5447(48, namedStack(class_1802.field_8793, 
            class_2561.method_43470("Clear Selection").method_27692(class_124.field_1061),
            List.of(class_2561.method_43470("Remove all selected perks.").method_27692(class_124.field_1080))));
            
        inv.method_5447(49, namedStack(class_1802.field_8733, 
            class_2561.method_43470("Confirm Selection").method_27692(class_124.field_1060),
            List.of(
                class_2561.method_43470("Selected: " + selected.size() + "/5 categories").method_27692(class_124.field_1080),
                class_2561.method_43470("Remaining Policy Points: " + plugin.getPerkService().remainingPoints(new java.util.ArrayList<>(selected))).method_27692(class_124.field_1075)
            )));
            
        String titleType = isSetPerks ? "Set Perks" : "Promised Perks";
        
        openScreen(player, inv, 6, class_2561.method_43470(titleType + " (Page " + (page + 1) + "/" + totalPages + ")"), (slot, clicker) -> {
            if (slot < 45) {
                int perkIndex = startIndex + slot;
                if (perkIndex < totalPerks) {
                    PerkDefinition perk = perks.get(perkIndex);
                    if (selected.contains(perk.id())) {
                        selected.remove(perk.id());
                    } else {
                        boolean categoryTaken = selected.stream()
                            .map(id -> PerkRegistry.find(id).map(PerkDefinition::category).orElse(null))
                            .anyMatch(category -> category == perk.category());
                        java.util.List<String> next = new java.util.ArrayList<>(selected);
                        next.add(perk.id());
                        var budget = PerkRegistry.validateBudget(next);
                        if (categoryTaken) {
                            clicker.method_7353(class_2561.method_43470("Only one " + perk.category().displayName() + " policy may be active.").method_27692(class_124.field_1061), false);
                        } else if (!budget.valid()) {
                            clicker.method_7353(class_2561.method_43470(String.join(" ", budget.errors())).method_27692(class_124.field_1061), false);
                        } else {
                            selected.add(perk.id());
                        }
                    }
                    openPerkSelectionMenu(clicker, isSetPerks, page);
                }
            } else if (slot == 45 && page > 0) {
                openPerkSelectionMenu(clicker, isSetPerks, page - 1);
            } else if (slot == 53 && page < totalPages - 1) {
                openPerkSelectionMenu(clicker, isSetPerks, page + 1);
            } else if (slot == 48) {
                selected.clear();
                openPerkSelectionMenu(clicker, isSetPerks, page);
            } else if (slot == 49) {
                clicker.method_7346();
                String perksStr = PerkRegistry.serialize(new java.util.ArrayList<>(selected));
                if (perksStr.isEmpty()) {
                    clicker.method_7353(class_2561.method_43470("No policies selected.").method_27692(class_124.field_1054), false);
                    activePerkSelections.remove(clicker.method_5667());
                    return;
                }
                if (isSetPerks) {
                    openPerkConfirmation(clicker, perksStr);
                } else {
                    MinecraftServer server = clicker.method_5682();
                    if (server != null) server.method_3734().method_44252(clicker.method_5671(), "kingdom promise " + perksStr);
                    activePerkSelections.remove(clicker.method_5667());
                }
            }
        });
    }

    public void openActivePerksMenu(class_3222 player) {
        java.util.List<String> ids = PerkRegistry.parseIds(officeService.getActivePerks());
        class_1277 inv = new class_1277(27);
        int slot = 0;
        for (String id : ids) {
            PerkDefinition perk = PerkRegistry.find(id).orElse(null);
            if (perk == null || slot >= 26) continue;
            inv.method_5447(slot++, namedStack(perk.icon(), class_2561.method_43470(perk.name()).method_27692(class_124.field_1065), List.of(
                class_2561.method_43470(perk.category().displayName() + " - " + perk.kind().label()).method_27692(class_124.field_1075),
                class_2561.method_43470(perk.description()).method_27692(class_124.field_1080)
            )));
        }
        if (ids.isEmpty()) inv.method_5447(13, namedStack(class_1802.field_8077, class_2561.method_43470("No active policies").method_27692(class_124.field_1080), List.of()));
        try {
            String ruler = officeService.getRuler();
            int trust = ruler == null ? 0 : plugin.getPersistence().trust().getScore(ruler);
            inv.method_5447(26, namedStack(class_1802.field_8448, class_2561.method_43470("King Trust: " + trust + "/100").method_27692(class_124.field_1060), List.of()));
        } catch (SQLException ignored) {}
        openScreen(player, inv, 3, class_2561.method_43470("Active Kingdom Policies"), (slotId, clicker) -> {});
    }

    private void openPerkConfirmation(class_3222 player, String perksStr) {
        java.util.List<String> ids = PerkRegistry.parseIds(perksStr);
        var budget = PerkRegistry.validateBudget(ids);
        class_1277 inv = new class_1277(9);
        inv.method_5447(2, namedStack(class_1802.field_8839, class_2561.method_43470("Confirm Policies").method_27692(class_124.field_1060), List.of(
            class_2561.method_43470("Remaining Policy Points: " + budget.remaining()).method_27692(class_124.field_1075),
            class_2561.method_43470(perksStr).method_27692(class_124.field_1080)
        )));
        inv.method_5447(6, namedStack(class_1802.field_8197, class_2561.method_43470("Cancel").method_27692(class_124.field_1061), List.of()));
        openScreen(player, inv, 1, class_2561.method_43470("Confirm Policy Decree"), (slot, clicker) -> {
            if (slot == 2) {
                clicker.method_7346();
                MinecraftServer server = clicker.method_5682();
                if (server != null) server.method_3734().method_44252(clicker.method_5671(), "kingdom setperks " + perksStr);
                activePerkSelections.remove(clicker.method_5667());
            } else if (slot == 6) {
                openPerkSelectionMenu(clicker, true, 0);
            }
        });
    }

    // ------------------------------------------------------------------
    // f. History menu
    // ------------------------------------------------------------------

    public void openHistoryMenu(class_3222 player, int page) {
        List<com.example.kingdoms.db.model.History> historyList = new java.util.ArrayList<>();
        try {
            historyList = plugin.getPersistence().history().findRecent(100);
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Failed to load history", e);
        }

        int itemsPerPage = 45;
        int totalPages = Math.max(1, (int) Math.ceil((double) historyList.size() / itemsPerPage));
        
        class_1277 inv = new class_1277(54);
        
        int startIndex = page * itemsPerPage;
        int endIndex = Math.min(startIndex + itemsPerPage, historyList.size());
        
        for (int i = startIndex; i < endIndex; i++) {
            com.example.kingdoms.db.model.History h = historyList.get(i);
            
            String eventType = h.getEventType();
            String targetUuid = h.getTargetUuid() != null ? h.getTargetUuid() : "Unknown";
            String title = "Event: " + eventType;
            String desc = h.getPayloadJson();
            
            if ("office_appointed".equals(eventType)) {
                title = "King Appointed";
                targetUuid = resolvePlayerName(player, h.getTargetUuid());
                desc = targetUuid + " became King.";
            } else if ("office_removed".equals(eventType)) {
                title = "King Removed";
                targetUuid = resolvePlayerName(player, h.getActorUuid());
                desc = targetUuid + " was removed from office.";
            }
            
            java.time.Instant time = java.time.Instant.ofEpochMilli(h.getCreatedAt());
            String date = java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm").withZone(java.time.ZoneOffset.UTC).format(time);
            
            inv.method_5447(i - startIndex, namedStack(class_1802.field_8407,
                class_2561.method_43470(title).method_27692(class_124.field_1065),
                List.of(
                    class_2561.method_43470(desc).method_27692(class_124.field_1068),
                    class_2561.method_43470(date).method_27692(class_124.field_1080)
                )));
        }
        
        if (page > 0) {
            inv.method_5447(45, namedStack(class_1802.field_8107, class_2561.method_43470("Previous Page").method_27692(class_124.field_1068), List.of()));
        }
        if (page < totalPages - 1) {
            inv.method_5447(53, namedStack(class_1802.field_8107, class_2561.method_43470("Next Page").method_27692(class_124.field_1068), List.of()));
        }
        
        inv.method_5447(49, namedStack(class_1802.field_8691, class_2561.method_43470("Back to Main Menu").method_27692(class_124.field_1054), List.of()));
        
        openScreen(player, inv, 6, class_2561.method_43470("Kingdom History (Page " + (page + 1) + "/" + totalPages + ")"), (slot, clicker) -> {
            if (slot == 45 && page > 0) {
                openHistoryMenu(clicker, page - 1);
            } else if (slot == 53 && page < totalPages - 1) {
                openHistoryMenu(clicker, page + 1);
            } else if (slot == 49) {
                openMainMenu(clicker);
            }
        });
    }

    // ------------------------------------------------------------------
    // Helpers
    // ------------------------------------------------------------------

    private void openScreen(
        class_3222 player,
        class_1277 inv,
        int rows,
        class_2561 title,
        java.util.function.BiConsumer<Integer, class_3222> clickHandler
    ) {
        player.method_17355(new class_747(
            (syncId, playerInv, p) -> new KingdomScreenHandler(
                syncId, playerInv, inv, rows,
                (slot, entity) -> {
                    if (entity instanceof class_3222 sp) clickHandler.accept(slot, sp);
                }
            ),
            title
        ));
    }

    private void castVoteFor(class_3222 player, Candidate candidate) {
        try {
            String officeId = plugin.getConfig().office().id();
            electionService.getCurrentElection(officeId).ifPresentOrElse(election -> {
                int playtimeTicks = player.method_14248()
                    .method_15025(net.minecraft.class_3468.field_15419.method_14956(net.minecraft.class_3468.field_15417));
                int playtimeMinutes = playtimeTicks / 20 / 60;

                try {
                    electionService.castVote(election.getId(), player.method_5845(),
                        candidate.getPlayerUuid(), playtimeMinutes);
                    String name = resolvePlayerName(player, candidate.getPlayerUuid());
                    player.method_7353(Messages.voteRecorded(name), false);
                } catch (ElectionException e) {
                    player.method_7353(Messages.error(e.getMessage()), false);
                } catch (SQLException e) {
                    KingdomsPlugin.LOGGER.error("Vote failed", e);
                    player.method_7353(Messages.error("A server error occurred."), false);
                }
            }, () -> player.method_7353(Messages.noActiveElection(), false));
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Vote lookup failed", e);
            player.method_7353(Messages.error("A server error occurred."), false);
        }
    }

    private List<Candidate> loadCandidates() {
        try {
            String officeId = plugin.getConfig().office().id();
            return electionService.getCurrentElection(officeId)
                .map(election -> {
                    try { return electionService.getCandidates(election.getId()); }
                    catch (SQLException e) { return List.<Candidate>of(); }
                })
                .orElse(List.of());
        } catch (SQLException e) {
            KingdomsPlugin.LOGGER.error("Failed to load candidates", e);
            return List.of();
        }
    }

    private String resolvePlayerName(class_3222 requester, String uuid) {
        MinecraftServer server = requester.method_5682();
        if (server == null) return uuid;
        try {
            class_3222 online = server.method_3760().method_14602(UUID.fromString(uuid));
            if (online != null) return online.method_5477().getString();
            // Fall back to DB username
            return plugin.getPersistence().players().findByUuid(uuid)
                .map(p -> p.getUsername() != null ? p.getUsername() : uuid)
                .orElse(uuid);
        } catch (Exception e) {
            return uuid;
        }
    }

    // ------------------------------------------------------------------
    // Item builders
    // ------------------------------------------------------------------

    /** Creates an ItemStack with a custom name and lore. */
    private static class_1799 namedStack(net.minecraft.class_1792 item, class_2561 name, List<class_2561> lore) {
        class_1799 stack = new class_1799(item);
        stack.method_7977(name);
        if (!lore.isEmpty()) addLore(stack, lore);
        return stack;
    }

    /** Creates a PLAYER_HEAD with the given owner UUID and display name. */
    private static class_1799 headStack(String ownerUuid, String displayName, List<class_2561> lore) {
        class_1799 stack = new class_1799(class_1802.field_8575);
        stack.method_7977(class_2561.method_43470(displayName).method_27692(class_124.field_1054));

        class_2487 nbt = stack.method_7948();
        class_2487 skullOwner = new class_2487();
        skullOwner.method_10582("Name", displayName);
        try {
            UUID uuid = UUID.fromString(ownerUuid);
            skullOwner.method_10566("Id", new class_2495(uuidToIntArray(uuid)));
        } catch (IllegalArgumentException ignored) {}
        nbt.method_10566("SkullOwner", skullOwner);

        if (!lore.isEmpty()) addLore(stack, lore);
        return stack;
    }

    private static void addLore(class_1799 stack, List<class_2561> lore) {
        class_2499 loreList = new class_2499();
        for (class_2561 line : lore) {
            loreList.add(class_2519.method_23256(class_2561.class_2562.method_10867(line)));
        }
        stack.method_7911("display").method_10566("Lore", loreList);
    }

    private static int[] uuidToIntArray(UUID uuid) {
        long msb = uuid.getMostSignificantBits();
        long lsb = uuid.getLeastSignificantBits();
        return new int[]{(int) (msb >> 32), (int) msb, (int) (lsb >> 32), (int) lsb};
    }
}
